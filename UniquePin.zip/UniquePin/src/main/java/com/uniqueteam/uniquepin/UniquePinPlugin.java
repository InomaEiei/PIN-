package com.uniqueteam.uniquepin;

import com.uniqueteam.uniquepin.command.PinAdminCommand;
import com.uniqueteam.uniquepin.command.PinCommand;
import com.uniqueteam.uniquepin.command.PinCreateCommand;
import com.uniqueteam.uniquepin.command.RepinCommand;
import com.uniqueteam.uniquepin.command.UniquePinCommand;
import com.uniqueteam.uniquepin.config.ConfigManager;
import com.uniqueteam.uniquepin.data.JdbcPinStorage;
import com.uniqueteam.uniquepin.data.PinStorage;
import com.uniqueteam.uniquepin.data.YamlPinStorage;
import com.uniqueteam.uniquepin.dialog.DialogService;
import com.uniqueteam.uniquepin.listener.DialogClickListener;
import com.uniqueteam.uniquepin.listener.LockListener;
import com.uniqueteam.uniquepin.pin.PinManager;
import com.uniqueteam.uniquepin.util.SchedulerUtil;
import java.io.File;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * UniquePin - native Dialog PIN lock for Paper/Folia 1.21.11.
 * No session: a PIN is required on every join.
 */
public final class UniquePinPlugin extends JavaPlugin {

  private ConfigManager configs;
  private PinStorage storage;
  private DialogService dialogs;
  private PinManager pins;
  private Object watchdogTask;

  @Override
  public void onEnable() {
    // Duplicate-jar guard: two copies would each lock players independently.
    try {
      org.bukkit.plugin.Plugin other = getServer().getPluginManager().getPlugin("UniquePin");
      if (other != null && other != this) {
        getLogger().severe("Duplicate UniquePin detected (" + other + "). "
            + "Remove one jar from plugins/ - disabling this copy.");
        getServer().getPluginManager().disablePlugin(this);
        return;
      }
    } catch (Exception ignored) {
      // guard must never block startup
    }
    saveDefaultConfig();
    saveResourceIfMissing("messages.yml");
    saveResourceIfMissing("gui.yml");
    saveResourceIfMissing("database.yml");

    configs = new ConfigManager(getDataFolder());
    configs.load();

    storage = createStorage();
    boolean spritesAvailable = detectSprites();
    dialogs = new DialogService(configs, spritesAvailable);
    pins = new PinManager(this, configs, storage, dialogs);

    getServer().getPluginManager().registerEvents(new LockListener(this, configs, pins), this);
    getServer().getPluginManager().registerEvents(new DialogClickListener(pins), this);
    getServer().getPluginManager().registerEvents(new com.uniqueteam.uniquepin.gui.InventoryPinListener(pins), this);

    register("pin", new PinCommand(this));
    register("repin", new RepinCommand(this));
    register("pincreate", new PinCreateCommand(this));
    register("uniquepin", new UniquePinCommand(this));
    register("pinadmin", new PinAdminCommand(this));

    // Watchdog: 5-minute timeout + fast dialog reopen (keeps dialog open if closed or moved).
    watchdogTask = SchedulerUtil.runTimer(this, 10L, 10L, () -> {
      try {
        pins.tick();
      } catch (Exception ex) {
        getLogger().warning("Watchdog error: " + ex.getMessage());
      }
    });

    maybePurge();

    // Ensure no online player remains trapped with corrupted 0 walk speed or potion effects
    for (org.bukkit.entity.Player p : getServer().getOnlinePlayers()) {
      if (pins.isBedrockExempt(p)) {
        pins.cleanupPlayer(p);
      } else if (p.getWalkSpeed() < 0.19f) {
        p.setWalkSpeed(0.2f);
      }
    }

    getLogger().info("UniquePin enabled (backend=" + storage.backendName()
        + ", no-session=true, folia-supported=true)");
  }

  @Override
  public void onDisable() {
    SchedulerUtil.cancel(watchdogTask);
    watchdogTask = null;
    if (pins != null) {
      // Never leave online players frozen by a wiped session map (/reload).
      pins.shutdownRestore();
    }
    if (storage != null) {
      try {
        storage.close();
      } catch (Exception ignored) {
        // non-fatal
      }
    }
    getLogger().info("UniquePin disabled.");
  }

  /** Reloads all YAML files and re-opens the correct dialog for locked players. */
  public void reloadAll() {
    reloadConfig();
    configs.reload();
    for (org.bukkit.entity.Player player : getServer().getOnlinePlayers()) {
      if (pins.isBedrockExempt(player)) {
        if (pins.isLocked(player.getUniqueId())) {
          pins.cleanupPlayer(player);
        }
        continue;
      }
      if (pins.isLocked(player.getUniqueId()) && pins.get(player.getUniqueId()) != null) {
        pins.openDialog(player);
        pins.sendChatPrompt(player);
      }
    }
  }

  public ConfigManager configs() {
    return configs;
  }

  public PinStorage storage() {
    return storage;
  }

  public PinManager pins() {
    return pins;
  }

  private void register(String name, Object executor) {
    PluginCommand cmd = getCommand(name);
    if (cmd == null) {
      getLogger().warning("Command not found in plugin.yml: " + name);
      return;
    }
    if (executor instanceof org.bukkit.command.CommandExecutor) {
      cmd.setExecutor((org.bukkit.command.CommandExecutor) executor);
    }
    if (executor instanceof org.bukkit.command.TabCompleter) {
      cmd.setTabCompleter((org.bukkit.command.TabCompleter) executor);
    }
  }

  private void saveResourceIfMissing(String name) {
    File file = new File(getDataFolder(), name);
    if (!file.exists()) {
      try {
        saveResource(name, false);
      } catch (Exception ex) {
        getLogger().warning("Could not save default " + name + ": " + ex.getMessage());
      }
    }
  }

  /** ObjectContents sprites need Paper 1.21.11+; older servers get text-only dialogs. */
  private boolean detectSprites() {
    try {
      Class<?> contents = Class.forName("net.kyori.adventure.text.object.ObjectContents");
      net.kyori.adventure.text.Component.class.getMethod("object", contents);
      getLogger().info("Native dialog sprites available (Paper 1.21.11+).");
      return true;
    } catch (Throwable ignored) {
      getLogger().warning("Old server build: dialog sprites unavailable, "
          + "using text-only dialogs. Use /pin and /pincreate in chat.");
      return false;
    }
  }

  private PinStorage createStorage() {
    String type = configs.storageType();
    try {
      if (type.equals("MYSQL")) {
        JdbcPinStorage jdbc = createMysql();
        if (jdbc != null) {
          return jdbc;
        }
      } else if (type.equals("SQLITE")) {
        JdbcPinStorage jdbc = createSqlite();
        if (jdbc != null) {
          return jdbc;
        }
      }
    } catch (Exception ex) {
      getLogger().warning("Database backend (" + type + ") unavailable: " + ex.getMessage()
          + " - falling back to YAML (no data loss).");
    }
    if (!type.equals("YAML")) {
      getLogger().warning("Database backend (" + type + ") unavailable"
          + " - falling back to YAML (no data loss).");
    }
    return new YamlPinStorage(getDataFolder(),
        configs.dbString("yaml.file", "storage/pin.yml"),
        configs.dbBool("yaml.backup-on-save", true),
        configs.dbInt("yaml.backup-keep", 5));
  }

  private JdbcPinStorage createSqlite() throws Exception {
    String fileName = configs.dbString("sqlite.file", "uniquepin.db");
    File dbFile = new File(getDataFolder(), fileName);
    if (dbFile.getParentFile() != null) {
      dbFile.getParentFile().mkdirs();
    }
    return JdbcPinStorage.sqlite(dbFile,
        configs.dbString("sqlite.table", "uniquepin_pins"),
        configs.dbString("sqlite.columns.uuid", "uuid"),
        configs.dbString("sqlite.columns.name", "name"),
        configs.dbString("sqlite.columns.hash", "pin_hash"),
        configs.dbString("sqlite.columns.salt", "salt"),
        configs.dbString("sqlite.columns.created", "created_at"),
        configs.dbString("sqlite.columns.updated", "updated_at"),
        configs.dbBool("debug-sql", false));
  }

  private JdbcPinStorage createMysql() throws Exception {
    ConfigurationSection pool = configs.dbSection("mysql.pool");
    int poolSize = pool == null ? 5 : pool.getInt("maximum-pool-size", 5);
    if (poolSize < 1) {
      poolSize = 5;
    }
    return JdbcPinStorage.mysql(
        configs.dbString("mysql.host", "localhost"),
        configs.dbInt("mysql.port", 3306),
        configs.dbString("mysql.database", "minecraft"),
        configs.dbString("mysql.user", "root"),
        configs.dbString("mysql.password", "change-me"),
        configs.dbBool("mysql.use-ssl", false),
        configs.dbBool("mysql.allow-public-key-retrieval", true),
        configs.dbString("mysql.table", "uniquepin_pins"),
        configs.dbString("mysql.columns.uuid", "uuid"),
        configs.dbString("mysql.columns.name", "name"),
        configs.dbString("mysql.columns.hash", "pin_hash"),
        configs.dbString("mysql.columns.salt", "salt"),
        configs.dbString("mysql.columns.created", "created_at"),
        configs.dbString("mysql.columns.updated", "updated_at"),
        configs.dbBool("debug-sql", false));
  }

  private void maybePurge() {
    if (!configs.dbBool("maintenance.purge-enabled", false)) {
      return;
    }
    long days = configs.dbLong("maintenance.purge-inactive-days", 180L);
    if (days <= 0) {
      return;
    }
    int removed = pins.purgeInactive(days * 24L * 60L * 60L * 1000L);
    if (removed >= 0) {
      getLogger().info("Purged " + removed + " inactive PIN record(s).");
    } else {
      getLogger().info("Purge is only supported on the YAML backend; skipped.");
    }
  }
}
