package com.uniqueteam.uniquepin.command;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import com.uniqueteam.uniquepin.config.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/**
 * /pinadmin repin <player> <newPin>
 * /pinadmin reset <player>
 * /pinadmin status <player>
 * Admin only.
 */
public final class PinAdminCommand implements CommandExecutor, TabCompleter {

  private final UniquePinPlugin plugin;

  public PinAdminCommand(UniquePinPlugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!sender.hasPermission("uniquepin.admin")) {
      sender.sendMessage(plugin.configs().msg("no-permission"));
      return true;
    }
    if (args.length == 0) {
      sender.sendMessage(plugin.configs().msg("usage",
          ConfigManager.ph("usage", "/pinadmin repin <player> <newPin>")));
      return true;
    }
    String sub = args[0].toLowerCase();
    if (sub.equals("repin")) {
      if (args.length != 3) {
        sender.sendMessage(plugin.configs().msg("usage-admin-repin"));
        return true;
      }
      plugin.pins().adminSetPin(sender, args[1], args[2]);
      return true;
    }
    if (sub.equals("reset")) {
      if (args.length != 2) {
        sender.sendMessage(plugin.configs().msg("usage-admin-reset"));
        return true;
      }
      plugin.pins().adminReset(sender, args[1]);
      return true;
    }
    if (sub.equals("status")) {
      if (args.length != 2) {
        sender.sendMessage(plugin.configs().msg("usage",
            ConfigManager.ph("usage", "/pinadmin status <player>")));
        return true;
      }
      plugin.pins().adminStatus(sender, args[1]);
      return true;
    }
    sender.sendMessage(plugin.configs().msg("unknown-command",
        ConfigManager.ph("command", args[0])));
    return true;
  }

  @Override
  public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
    List<String> out = new ArrayList<>();
    if (args.length == 1) {
      for (String s : List.of("repin", "reset", "status")) {
        if (s.startsWith(args[0].toLowerCase())) {
          out.add(s);
        }
      }
      return out;
    }
    if (args.length == 2) {
      String prefix = args[1].toLowerCase();
      for (Player p : Bukkit.getOnlinePlayers()) {
        if (p.getName().toLowerCase().startsWith(prefix)) {
          out.add(p.getName());
        }
      }
    }
    return out;
  }
}
