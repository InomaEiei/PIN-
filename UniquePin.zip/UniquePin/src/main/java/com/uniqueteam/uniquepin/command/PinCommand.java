package com.uniqueteam.uniquepin.command;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/**
 * /pin [pin] [confirmPin]
 * - no args: open the PIN dialog (or show usage when already unlocked)
 * - 1 arg: enter PIN (login) or first setup step
 * - 2 args: setup with confirmation in one command
 */
public final class PinCommand implements CommandExecutor, TabCompleter {

  private final UniquePinPlugin plugin;

  public PinCommand(UniquePinPlugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!(sender instanceof Player)) {
      sender.sendMessage(plugin.configs().msg("player-only"));
      return true;
    }
    Player player = (Player) sender;
    if (plugin.pins().isBedrockExempt(player)) {
      player.sendMessage(plugin.configs().msg("bedrock-exempt"));
      return true;
    }
    if (!player.hasPermission("uniquepin.player")) {
      player.sendMessage(plugin.configs().msg("no-permission"));
      return true;
    }
    if (args.length == 0) {
      if (plugin.pins().isLocked(player.getUniqueId())) {
        plugin.pins().openDialog(player);
      } else {
        player.sendMessage(plugin.configs().msg("usage-pin"));
        for (net.kyori.adventure.text.Component line
            : plugin.configs().msgList("help", null)) {
          player.sendMessage(line);
        }
      }
      return true;
    }
    if (args.length == 1) {
      plugin.pins().confirmPinCommand(player, args[0], null);
      return true;
    }
    if (args.length == 2) {
      plugin.pins().confirmPinCommand(player, args[0], args[1]);
      return true;
    }
    player.sendMessage(plugin.configs().msg("usage-pin"));
    return true;
  }

  @Override
  public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
    return new ArrayList<>();
  }
}
