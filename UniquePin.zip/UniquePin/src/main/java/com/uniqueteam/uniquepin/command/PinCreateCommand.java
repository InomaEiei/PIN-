package com.uniqueteam.uniquepin.command;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** /pincreate <pin> <pin> - explicit PIN creation (same rules as setup). */
public final class PinCreateCommand implements CommandExecutor, TabCompleter {

  private final UniquePinPlugin plugin;

  public PinCreateCommand(UniquePinPlugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!(sender instanceof Player)) {
      sender.sendMessage(plugin.configs().msg("player-only"));
      return true;
    }
    Player player = (Player) sender;
    if (plugin.pins().isBedrockExempt(player)) {
      player.sendMessage(plugin.configs().msg("bedrock-exempt"));
      return true;
    }
    if (!player.hasPermission("uniquepin.player")) {
      player.sendMessage(plugin.configs().msg("no-permission"));
      return true;
    }
    if (args.length != 2) {
      player.sendMessage(plugin.configs().msg("usage-pincreate"));
      return true;
    }
    plugin.pins().createPinCommand(player, args[0], args[1]);
    return true;
  }

  @Override
  public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
    return new ArrayList<>();
  }
}
