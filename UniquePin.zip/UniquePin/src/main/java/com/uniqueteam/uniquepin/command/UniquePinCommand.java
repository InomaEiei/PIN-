package com.uniqueteam.uniquepin.command;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

/** /uniquepin reload */
public final class UniquePinCommand implements CommandExecutor, TabCompleter {

  private final UniquePinPlugin plugin;

  public UniquePinCommand(UniquePinPlugin plugin) {
    this.plugin = plugin;
  }

  @Override
  public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
    if (!sender.hasPermission("uniquepin.admin")) {
      sender.sendMessage(plugin.configs().msg("no-permission"));
      return true;
    }
    if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
      plugin.reloadAll();
      sender.sendMessage(plugin.configs().msg("reload-success"));
      return true;
    }
    sender.sendMessage(plugin.configs().msg("invalid-command"));
    sender.sendMessage(plugin.configs().msg("usage",
        com.uniqueteam.uniquepin.config.ConfigManager.ph("usage", "/uniquepin reload")));
    return true;
  }

  @Override
  public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
    List<String> out = new ArrayList<>();
    if (args.length == 1 && "reload".startsWith(args[0].toLowerCase())) {
      out.add("reload");
    }
    return out;
  }
}
