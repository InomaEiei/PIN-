package com.uniqueteam.uniquepin.config;

import com.uniqueteam.uniquepin.util.Mini;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Loads and serves config.yml / messages.yml / gui.yml / database.yml.
 */
public final class ConfigManager {

  private final File dataFolder;
  private YamlConfiguration config;
  private YamlConfiguration messages;
  private YamlConfiguration gui;
  private YamlConfiguration database;

  public ConfigManager(File dataFolder) {
    this.dataFolder = dataFolder;
  }

  public void load() {
    if (!dataFolder.exists()) {
      dataFolder.mkdirs();
    }
    config = loadOrDefault("config.yml");
    messages = loadOrDefault("messages.yml");
    gui = loadOrDefault("gui.yml");
    database = loadOrDefault("database.yml");
  }

  public void reload() {
    load();
  }

  private YamlConfiguration loadOrDefault(String name) {
    File file = new File(dataFolder, name);
    // First run: defaults were saved by the plugin from resources.
    if (file.exists()) {
      try {
        return YamlConfiguration.loadConfiguration(file);
      } catch (Exception ex) {
        return new YamlConfiguration();
      }
    }
    return new YamlConfiguration();
  }

  // ---------- config.yml ----------

  public int pinLength() {
    return Math.max(4, Math.min(12, config.getInt("pin.length", 6)));
  }

  public boolean numericOnly() {
    return config.getBoolean("pin.numeric-only", true);
  }

  public boolean forbidRepeatingDigit() {
    return config.getBoolean("pin.forbid-repeating-digit", true);
  }

  public List<String> forbiddenPins() {
    return config.getStringList("pin.forbidden");
  }

  public String hashAlgorithm() {
    return config.getString("security.hash-algorithm", "SHA-256");
  }

  public int saltBytes() {
    return Math.max(8, config.getInt("security.salt-bytes", 16));
  }

  public long verifyDelayMs() {
    return Math.max(0L, config.getLong("security.verify-delay-ms", 0L));
  }

  public int maxClicksPerSecond() {
    return Math.max(2, config.getInt("security.max-clicks-per-second", 8));
  }

  public int maxAttempts() {
    return Math.max(1, config.getInt("login.max-attempts", 3));
  }

  public int lockoutSeconds() {
    return Math.max(1, config.getInt("login.lockout-seconds", 60));
  }

  public int timeoutMinutes() {
    return Math.max(1, config.getInt("login.timeout-minutes", 5));
  }

  public long timeoutMillis() {
    return timeoutMinutes() * 60_000L;
  }

  public boolean lock(String key) {
    return config.getBoolean("lock." + key, true);
  }

  public List<String> allowedCommands() {
    List<String> raw = config.getStringList("lock.allowed-commands");
    if (raw.isEmpty()) {
      raw = List.of("/pin", "/repin", "/pincreate");
    }
    List<String> out = new ArrayList<>();
    for (String s : raw) {
      out.add(s.toLowerCase());
    }
    return out;
  }

  public double maxPositionDrift() {
    return Math.max(0.5, config.getDouble("lock.max-position-drift", 1.5));
  }

  public long joinDelayTicks() {
    return Math.max(1L, config.getLong("dialog.join-delay-ticks", 30L));
  }

  public boolean reopenEnabled() {
    return config.getBoolean("dialog.reopen-enabled", true);
  }

  public long reopenIntervalSeconds() {
    return Math.max(1L, config.getLong("dialog.reopen-interval-seconds", 1L));
  }

  public boolean keypadAuthoritative() {
    return config.getBoolean("dialog.keypad-authoritative", true);
  }

  public boolean openChatPrompt() {
    return config.getBoolean("dialog.open-chat-prompt", true);
  }

  public String guiMode() {
    return config.getString("dialog.mode", "AUTO").toUpperCase();
  }

  // ---------- bedrock / floodgate ----------

  public boolean bedrockExemptEnabled() {
    return config.getBoolean("bedrock.exempt-enabled", true);
  }

  public String bedrockPrefix() {
    return config.getString("bedrock.prefix", ".");
  }

  public boolean checkFloodgateApi() {
    return config.getBoolean("bedrock.check-floodgate-api", true);
  }

  public String storageType() {
    return config.getString("storage.type", "YAML").toUpperCase();
  }

  public boolean debug() {
    return config.getBoolean("debug", false);
  }

  // ---------- messages.yml ----------

  public String prefixRaw() {
    return messages.getString("prefix", "<#3DFF77>ᴜɴɪǫᴜᴇ ᴘɪɴ</#3DFF77> <#777777>│</#777777>");
  }

  public Component msg(String key) {
    return msg(key, Collections.emptyMap());
  }

  public Component msg(String key, Map<String, String> placeholders) {
    String raw = messages.getString(key, "<red>Missing message: " + key);
    raw = raw.replace("<prefix>", prefixRaw());
    if (placeholders != null) {
      for (Map.Entry<String, String> e : placeholders.entrySet()) {
        raw = raw.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
      }
    }
    return Mini.mm(raw);
  }

  public List<Component> msgList(String key, Map<String, String> placeholders) {
    List<String> raw = messages.getStringList(key);
    List<Component> out = new ArrayList<>(raw.size());
    for (String line : raw) {
      String l = line.replace("<prefix>", prefixRaw());
      if (placeholders != null) {
        for (Map.Entry<String, String> e : placeholders.entrySet()) {
          l = l.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
        }
      }
      out.add(Mini.mm(l));
    }
    return out;
  }

  public static Map<String, String> ph(String... kv) {
    Map<String, String> map = new HashMap<>();
    for (int i = 0; i + 1 < kv.length; i += 2) {
      map.put(kv[i], kv[i + 1]);
    }
    return map;
  }

  // ---------- gui.yml ----------

  public String guiTitle() {
    return gui.getString("dialog.title", "<#3DFF77><bold>ᴜɴɪǫᴜᴇ ᴘɪɴ</bold></#3DFF77>");
  }

  public String guiCredit() {
    return gui.getString("dialog.credit", "<#3A3A3A>ᴍᴀᴅᴇ ʙʏ ᴜɴɪǫᴜᴇ</#3A3A3A>");
  }

  public boolean guiCanCloseWithEscape() {
    return gui.getBoolean("dialog.can-close-with-escape", false);
  }

  public int guiColumns() {
    return Math.max(1, Math.min(4, gui.getInt("dialog.columns", 3)));
  }

  public String pinDisplayFormat(Map<String, String> placeholders) {
    String raw = gui.getString("dialog.pin-display-format", "<gray>พิน: </gray><#555555>[</#555555> {dots} <#555555>]</#555555>");
    return applyGuiPlaceholders(raw, placeholders);
  }

  public String pinDotFilled() {
    return gui.getString("dialog.pin-dot-filled", "●");
  }

  public String pinDotEmpty() {
    return gui.getString("dialog.pin-dot-empty", "○");
  }

  public String pinDotFilledColor() {
    return gui.getString("dialog.pin-dot-filled-color", "<#3DFF77>");
  }

  public String pinDotEmptyColor() {
    return gui.getString("dialog.pin-dot-empty-color", "<#555555>");
  }

  public String pinDisplayPrefix() {
    return gui.getString("dialog.pin-display-prefix", "<gray>พิน: </gray><#777777>[</#777777> ");
  }

  public String pinDisplaySuffix() {
    return gui.getString("dialog.pin-display-suffix", " <#777777>]</#777777>");
  }

  public String pinDisplaySprite() {
    return gui.getString("dialog.pin-display-sprite", "paper");
  }

  public int guiButtonWidth() {
    if (gui.contains("dialog.button-width")) {
      return clamp(gui.getInt("dialog.button-width", 50), 1, 1024);
    }
    if (gui.contains("dialog.wide-button-width")) {
      return clamp(gui.getInt("dialog.wide-button-width", 50), 1, 1024);
    }
    return 50;
  }

  public int guiInputWidth() {
    return clamp(gui.getInt("dialog.input-width", 200), 1, 1024);
  }

  public int guiDigitButtonWidth() {
    return guiButtonWidth();
  }

  public int guiWideButtonWidth() {
    return guiButtonWidth();
  }

  public List<String> guiDescription(String section, Map<String, String> placeholders) {    List<String> raw = gui.getStringList(section + ".description");
    List<String> out = new ArrayList<>(raw.size());
    for (String line : raw) {
      out.add(applyGuiPlaceholders(line, placeholders));
    }
    return out;
  }

  public String guiText(String section, String key, Map<String, String> placeholders) {
    String raw = gui.getString(section + "." + key, "");
    return applyGuiPlaceholders(raw, placeholders);
  }

  public String guiTextFallback(String section, String key, String fallback) {
    String raw = gui.getString(section + "." + key, "");
    if (raw == null || raw.isEmpty()) {
      raw = gui.getString("dialog." + key, "");
    }
    return (raw == null || raw.isEmpty()) ? fallback : raw;
  }

  public List<String> guiStringList(String section, String key) {
    List<String> raw = gui.getStringList(section + "." + key);
    List<String> out = new ArrayList<>(raw.size());
    for (String s : raw) {
      out.add(s == null ? "" : s.trim());
    }
    return out;
  }

  /** Raw message string (no prefix) for dialog-embedded lines. */
  public String rawMsg(String key, Map<String, String> placeholders) {
    String raw = messages.getString(key, "");
    if (placeholders != null) {
      for (Map.Entry<String, String> e : placeholders.entrySet()) {
        raw = raw.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
      }
    }
    return raw;
  }

  // ---------- gui.yml sounds ----------

  public boolean soundsEnabled() {
    return gui.getBoolean("sounds.enabled", true);
  }

  public String soundType(String name, String def) {
    return gui.getString("sounds." + name + ".type", def);
  }

  public float soundVolume(String name, float def) {
    try {
      return (float) gui.getDouble("sounds." + name + ".volume", def);
    } catch (Exception ex) {
      return def;
    }
  }

  public float soundPitch(String name, float def) {
    try {
      return (float) gui.getDouble("sounds." + name + ".pitch", def);
    } catch (Exception ex) {
      return def;
    }
  }

  public float soundBasePitch() {
    try {
      return (float) gui.getDouble("sounds.digit.base-pitch", 0.8);
    } catch (Exception ex) {
      return 0.8f;
    }
  }

  public float soundPitchStep() {
    try {
      return (float) gui.getDouble("sounds.digit.pitch-step", 0.07);
    } catch (Exception ex) {
      return 0.07f;
    }
  }

  private String applyGuiPlaceholders(String raw, Map<String, String> placeholders) {
    String s = raw.replace("<prefix>", prefixRaw());
    if (placeholders != null) {
      for (Map.Entry<String, String> e : placeholders.entrySet()) {
        s = s.replace("{" + e.getKey() + "}", e.getValue() == null ? "" : e.getValue());
      }
    }
    return s;
  }

  public List<GuiItem> guiItems(String section) {
    return guiItems(section, "items");
  }

  public List<GuiItem> guiItems(String section, String key) {
    List<GuiItem> out = new ArrayList<>();
    List<?> raw = gui.getList(section + "." + key, Collections.emptyList());
    for (Object o : raw) {
      if (o instanceof Map) {
        @SuppressWarnings("unchecked")
        Map<String, Object> m = (Map<String, Object>) o;
        out.add(new GuiItem(
            String.valueOf(m.getOrDefault("material", "PAPER")),
            String.valueOf(m.getOrDefault("name", "")),
            toInt(m.get("width"), 24),
            toInt(m.get("height"), 24),
            toBool(m.get("decorations"), false),
            toBool(m.get("tooltip"), true)));
      }
    }
    return out;
  }

  private static int toInt(Object o, int def) {
    if (o instanceof Number) {
      return ((Number) o).intValue();
    }
    try {
      return Integer.parseInt(String.valueOf(o));
    } catch (Exception ex) {
      return def;
    }
  }

  private static boolean toBool(Object o, boolean def) {
    if (o instanceof Boolean) {
      return (Boolean) o;
    }
    if (o == null) {
      return def;
    }
    return Boolean.parseBoolean(String.valueOf(o));
  }

  private static int clamp(int v, int min, int max) {
    return Math.max(min, Math.min(max, v));
  }

  public record GuiItem(String material, String name, int width, int height,
      boolean decorations, boolean tooltip) {
  }

  // ---------- database.yml ----------

  public ConfigurationSection dbSection(String path) {
    return database.getConfigurationSection(path);
  }

  public String dbString(String path, String def) {
    return database.getString(path, def);
  }

  public boolean dbBool(String path, boolean def) {
    return database.getBoolean(path, def);
  }

  public int dbInt(String path, int def) {
    return database.getInt(path, def);
  }

  public long dbLong(String path, long def) {
    return database.getLong(path, def);
  }

  public File dataFolder() {
    return dataFolder;
  }
}
