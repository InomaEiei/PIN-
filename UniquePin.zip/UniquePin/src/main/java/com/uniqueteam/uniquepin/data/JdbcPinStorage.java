package com.uniqueteam.uniquepin.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * JDBC backend for SQLITE / MYSQL using only JDK java.sql.
 * Drivers are detected at runtime; if missing, the plugin falls back to YAML.
 */
public final class JdbcPinStorage implements PinStorage {

  private final String backendName;
  private final String jdbcUrl;
  private final String user;
  private final String password;
  private final String table;
  private final String colUuid;
  private final String colName;
  private final String colHash;
  private final String colSalt;
  private final String colCreated;
  private final String colUpdated;
  private final boolean debugSql;

  private JdbcPinStorage(String backendName, String jdbcUrl, String user, String password,
      String table, String colUuid, String colName, String colHash, String colSalt,
      String colCreated, String colUpdated, boolean debugSql) {
    this.backendName = backendName;
    this.jdbcUrl = jdbcUrl;
    this.user = user;
    this.password = password;
    this.table = table;
    this.colUuid = colUuid;
    this.colName = colName;
    this.colHash = colHash;
    this.colSalt = colSalt;
    this.colCreated = colCreated;
    this.colUpdated = colUpdated;
    this.debugSql = debugSql;
  }

  public static JdbcPinStorage sqlite(java.io.File dbFile, String table,
      String cUuid, String cName, String cHash, String cSalt, String cCreated, String cUpdated,
      boolean debugSql) throws Exception {
    Class.forName("org.sqlite.JDBC");
    String url = "jdbc:sqlite:" + dbFile.getAbsolutePath();
    JdbcPinStorage storage = new JdbcPinStorage("SQLITE", url, null, null,
        table, cUuid, cName, cHash, cSalt, cCreated, cUpdated, debugSql);
    storage.initTable();
    return storage;
  }

  public static JdbcPinStorage mysql(String host, int port, String database, String user,
      String password, boolean useSsl, boolean allowPublicKeyRetrieval, String table,
      String cUuid, String cName, String cHash, String cSalt, String cCreated, String cUpdated,
      boolean debugSql) throws Exception {
    Class.forName("com.mysql.cj.jdbc.Driver");
    String url = "jdbc:mysql://" + host + ":" + port + "/" + database
        + "?useSSL=" + useSsl
        + "&allowPublicKeyRetrieval=" + allowPublicKeyRetrieval
        + "&serverTimezone=UTC";
    JdbcPinStorage storage = new JdbcPinStorage("MYSQL", url, user, password,
        table, cUuid, cName, cHash, cSalt, cCreated, cUpdated, debugSql);
    storage.initTable();
    return storage;
  }

  private synchronized Connection open() throws Exception {
    if (user == null) {
      return DriverManager.getConnection(jdbcUrl);
    }
    return DriverManager.getConnection(jdbcUrl, user, password);
  }

  private void initTable() throws Exception {
    String sql = "CREATE TABLE IF NOT EXISTS " + table + " ("
        + colUuid + " VARCHAR(36) PRIMARY KEY, "
        + colName + " VARCHAR(32), "
        + colHash + " VARCHAR(128), "
        + colSalt + " VARCHAR(64), "
        + colCreated + " BIGINT, "
        + colUpdated + " BIGINT)";
    log(sql);
    try (Connection con = open(); Statement st = con.createStatement()) {
      st.execute(sql);
    }
  }

  private void log(String sql) {
    if (debugSql) {
      System.out.println("[UniquePin][SQL][" + backendName + "] " + sql);
    }
  }

  @Override
  public String backendName() {
    return backendName;
  }

  @Override
  public synchronized boolean hasPin(UUID uuid) {
    return get(uuid) != null;
  }

  @Override
  public synchronized PinRecord get(UUID uuid) {
    String sql = "SELECT " + colName + "," + colHash + "," + colSalt + "," + colCreated + "," + colUpdated
        + " FROM " + table + " WHERE " + colUuid + "=?";
    log(sql);
    try (Connection con = open(); PreparedStatement ps = con.prepareStatement(sql)) {
      ps.setString(1, uuid.toString());
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          return new PinRecord(uuid.toString(), rs.getString(1), rs.getString(2),
              rs.getString(3), rs.getLong(4), rs.getLong(5));
        }
      }
    } catch (Exception ignored) {
      // query failure returns null, never throws into game thread
    }
    return null;
  }

  @Override
  public synchronized Collection<PinRecord> all() {
    List<PinRecord> out = new ArrayList<>();
    String sql = "SELECT " + colUuid + "," + colName + "," + colHash + "," + colSalt + "," + colCreated + "," + colUpdated
        + " FROM " + table;
    log(sql);
    try (Connection con = open(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(sql)) {
      while (rs.next()) {
        out.add(new PinRecord(rs.getString(1), rs.getString(2), rs.getString(3),
            rs.getString(4), rs.getLong(5), rs.getLong(6)));
      }
    } catch (Exception ignored) {
      // return what we have
    }
    return out;
  }

  @Override
  public synchronized void save(PinRecord record) {
    String update = "UPDATE " + table + " SET " + colName + "=?, " + colHash + "=?, " + colSalt + "=?, "
        + colCreated + "=?, " + colUpdated + "=? WHERE " + colUuid + "=?";
    log(update);
    try (Connection con = open(); PreparedStatement ps = con.prepareStatement(update)) {
      ps.setString(1, record.name());
      ps.setString(2, record.hash());
      ps.setString(3, record.salt());
      ps.setLong(4, record.createdAt());
      ps.setLong(5, record.updatedAt());
      ps.setString(6, record.uuid());
      if (ps.executeUpdate() == 0) {
        String insert = "INSERT INTO " + table + " (" + colUuid + "," + colName + "," + colHash + ","
            + colSalt + "," + colCreated + "," + colUpdated + ") VALUES (?,?,?,?,?,?)";
        log(insert);
        try (PreparedStatement ps2 = con.prepareStatement(insert)) {
          ps2.setString(1, record.uuid());
          ps2.setString(2, record.name());
          ps2.setString(3, record.hash());
          ps2.setString(4, record.salt());
          ps2.setLong(5, record.createdAt());
          ps2.setLong(6, record.updatedAt());
          ps2.executeUpdate();
        }
      }
    } catch (Exception ignored) {
      // storage errors must never crash the server thread
    }
  }

  @Override
  public synchronized void delete(UUID uuid) {
    String sql = "DELETE FROM " + table + " WHERE " + colUuid + "=?";
    log(sql);
    try (Connection con = open(); PreparedStatement ps = con.prepareStatement(sql)) {
      ps.setString(1, uuid.toString());
      ps.executeUpdate();
    } catch (Exception ignored) {
      // non-fatal
    }
  }

  @Override
  public void flush() {
    // JDBC writes are immediate
  }

  @Override
  public void close() {
    // connections are opened per-operation and closed immediately
  }
}
