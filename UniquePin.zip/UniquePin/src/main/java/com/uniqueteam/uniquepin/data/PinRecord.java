package com.uniqueteam.uniquepin.data;

/**
 * Stored PIN record. Only hash + salt are persisted, never the real PIN.
 */
public final class PinRecord {

  private final String uuid;
  private String name;
  private String hash;
  private String salt;
  private long createdAt;
  private long updatedAt;
  private long lastLogin;

  public PinRecord(String uuid, String name, String hash, String salt, long createdAt, long updatedAt) {
    this(uuid, name, hash, salt, createdAt, updatedAt, 0L);
  }

  public PinRecord(String uuid, String name, String hash, String salt, long createdAt, long updatedAt,
      long lastLogin) {
    this.uuid = uuid;
    this.name = name;
    this.hash = hash;
    this.salt = salt;
    this.createdAt = createdAt;
    this.updatedAt = updatedAt;
    this.lastLogin = lastLogin;
  }

  public String uuid() {
    return uuid;
  }

  public String name() {
    return name;
  }

  public void name(String name) {
    this.name = name;
  }

  public String hash() {
    return hash;
  }

  public void hash(String hash) {
    this.hash = hash;
  }

  public String salt() {
    return salt;
  }

  public void salt(String salt) {
    this.salt = salt;
  }

  public long createdAt() {
    return createdAt;
  }

  public long updatedAt() {
    return updatedAt;
  }

  public void updatedAt(long updatedAt) {
    this.updatedAt = updatedAt;
  }

  public long lastLogin() {
    return lastLogin;
  }

  public void lastLogin(long lastLogin) {
    this.lastLogin = lastLogin;
  }
}
