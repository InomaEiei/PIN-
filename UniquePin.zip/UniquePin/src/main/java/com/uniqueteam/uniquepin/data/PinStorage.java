package com.uniqueteam.uniquepin.data;

import java.util.Collection;
import java.util.UUID;

/**
 * Storage backend contract. All methods are thread-safe and synchronous;
 * callers must not run them on the main thread for remote databases.
 */
public interface PinStorage {

  String backendName();

  boolean hasPin(UUID uuid);

  PinRecord get(UUID uuid);

  Collection<PinRecord> all();

  void save(PinRecord record);

  void delete(UUID uuid);

  /** Records a successful unlock (used by purge). Default: unsupported. */
  default void touchLogin(UUID uuid) {
  }

  void flush();

  void close();
}
