package com.uniqueteam.uniquepin.data;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

/**
 * Storage backend storing data in plugins/UniquePin/storage/pin.yml
 * with individual player records mirrored in storage/players/<uuid>.yml
 * and automated backup rotation in storage/backups/.
 */
public final class YamlPinStorage implements PinStorage {

  private final File dataFolder;
  private final File storageDir;
  private final File file;
  private final File playersDir;
  private final File backupDir;
  private final boolean backupOnSave;
  private final int backupKeep;
  private YamlConfiguration data = new YamlConfiguration();

  public YamlPinStorage(File dataFolder, String fileName, boolean backupOnSave, int backupKeep) {
    this.dataFolder = dataFolder;
    this.storageDir = new File(dataFolder, "storage");
    if (!this.storageDir.exists()) {
      this.storageDir.mkdirs();
    }
    this.playersDir = new File(storageDir, "players");
    if (!this.playersDir.exists()) {
      this.playersDir.mkdirs();
    }
    this.backupDir = new File(storageDir, "backups");
    if (!this.backupDir.exists()) {
      this.backupDir.mkdirs();
    }

    // Default primary file is storage/pin.yml
    File targetFile = new File(dataFolder, fileName);
    if (!targetFile.getName().endsWith(".yml")) {
      targetFile = new File(storageDir, "pin.yml");
    }
    this.file = targetFile;
    this.backupOnSave = backupOnSave;
    this.backupKeep = Math.max(0, backupKeep);

    reload();
  }

  private synchronized void reload() {
    if (file.exists()) {
      try {
        data = YamlConfiguration.loadConfiguration(file);
      } catch (Exception ex) {
        data = new YamlConfiguration();
      }
    } else {
      data = new YamlConfiguration();
    }

    // Automatic migration from legacy files if main storage is empty
    if (!data.contains("pins") || data.getConfigurationSection("pins") == null || data.getConfigurationSection("pins").getKeys(false).isEmpty()) {
      migrateLegacyFiles();
    }

    // Ensure all existing pins in pin.yml have corresponding storage/players/<uuid>.yml files
    syncPlayerFiles();
  }

  private void migrateLegacyFiles() {
    File[] legacyCandidates = new File[]{
        new File(dataFolder, "pins.yml"),
        new File(dataFolder, "pin.yml"),
        new File(storageDir, "pins.yml")
    };
    for (File old : legacyCandidates) {
      if (old.exists() && !old.equals(file)) {
        try {
          YamlConfiguration oldConfig = YamlConfiguration.loadConfiguration(old);
          ConfigurationSection oldPins = oldConfig.getConfigurationSection("pins");
          if (oldPins != null && !oldPins.getKeys(false).isEmpty()) {
            for (String key : oldPins.getKeys(false)) {
              ConfigurationSection p = oldPins.getConfigurationSection(key);
              if (p != null) {
                data.set("pins." + key + ".name", p.getString("name", "?"));
                data.set("pins." + key + ".hash", p.getString("hash", ""));
                data.set("pins." + key + ".salt", p.getString("salt", ""));
                data.set("pins." + key + ".created", p.getLong("created", System.currentTimeMillis()));
                data.set("pins." + key + ".updated", p.getLong("updated", System.currentTimeMillis()));
                data.set("pins." + key + ".last-login", p.getLong("last-login", 0L));
              }
            }
            flush();
            // Safely rename old legacy file to .migrated so no confusion remains
            File migrated = new File(old.getParentFile(), old.getName() + ".migrated");
            old.renameTo(migrated);
            break;
          }
        } catch (Exception ignored) {
        }
      }
    }
  }

  private void syncPlayerFiles() {
    ConfigurationSection root = data.getConfigurationSection("pins");
    if (root != null) {
      for (String uuidStr : root.getKeys(false)) {
        PinRecord rec = getRecordFromSection(uuidStr);
        if (rec != null) {
          saveIndividualPlayerFile(rec);
        }
      }
    }
  }

  @Override
  public String backendName() {
    return "YAML (storage/pin.yml)";
  }

  @Override
  public synchronized boolean hasPin(UUID uuid) {
    if (data.contains("pins." + uuid)) {
      return true;
    }
    File playerFile = new File(playersDir, uuid + ".yml");
    return playerFile.exists();
  }

  @Override
  public synchronized PinRecord get(UUID uuid) {
    PinRecord rec = getRecordFromSection(uuid.toString());
    if (rec != null) {
      return rec;
    }
    // Fallback: check individual storage/players/<uuid>.yml
    File playerFile = new File(playersDir, uuid + ".yml");
    if (playerFile.exists()) {
      try {
        YamlConfiguration pcfg = YamlConfiguration.loadConfiguration(playerFile);
        rec = new PinRecord(
            uuid.toString(),
            pcfg.getString("name", "?"),
            pcfg.getString("hash", ""),
            pcfg.getString("salt", ""),
            pcfg.getLong("created", 0L),
            pcfg.getLong("updated", 0L),
            pcfg.getLong("last-login", 0L));
        // Re-cache into main data
        saveToData(rec);
        return rec;
      } catch (Exception ignored) {
      }
    }
    return null;
  }

  private PinRecord getRecordFromSection(String uuidStr) {
    ConfigurationSection sec = data.getConfigurationSection("pins." + uuidStr);
    if (sec == null) {
      return null;
    }
    return new PinRecord(
        uuidStr,
        sec.getString("name", "?"),
        sec.getString("hash", ""),
        sec.getString("salt", ""),
        sec.getLong("created", 0L),
        sec.getLong("updated", 0L),
        sec.getLong("last-login", 0L));
  }

  @Override
  public synchronized Collection<PinRecord> all() {
    List<PinRecord> out = new ArrayList<>();
    ConfigurationSection root = data.getConfigurationSection("pins");
    if (root != null) {
      for (String key : root.getKeys(false)) {
        try {
          PinRecord rec = getRecordFromSection(key);
          if (rec != null) {
            out.add(rec);
          }
        } catch (Exception ignored) {
        }
      }
    }
    return out;
  }

  @Override
  public synchronized void save(PinRecord record) {
    saveToData(record);
    flush();
    saveIndividualPlayerFile(record);
  }

  private void saveToData(PinRecord record) {
    String base = "pins." + record.uuid();
    data.set(base + ".name", record.name());
    data.set(base + ".hash", record.hash());
    data.set(base + ".salt", record.salt());
    data.set(base + ".created", record.createdAt());
    data.set(base + ".updated", record.updatedAt());
    data.set(base + ".last-login", record.lastLogin());
  }

  private void saveIndividualPlayerFile(PinRecord record) {
    try {
      File playerFile = new File(playersDir, record.uuid() + ".yml");
      YamlConfiguration pcfg = new YamlConfiguration();
      pcfg.set("uuid", record.uuid());
      pcfg.set("name", record.name());
      pcfg.set("hash", record.hash());
      pcfg.set("salt", record.salt());
      pcfg.set("created", record.createdAt());
      pcfg.set("updated", record.updatedAt());
      pcfg.set("last-login", record.lastLogin());
      pcfg.save(playerFile);
    } catch (Exception ignored) {
    }
  }

  @Override
  public synchronized void delete(UUID uuid) {
    data.set("pins." + uuid, null);
    flush();
    try {
      File playerFile = new File(playersDir, uuid + ".yml");
      if (playerFile.exists()) {
        playerFile.delete();
      }
    } catch (Exception ignored) {
    }
  }

  @Override
  public synchronized void flush() {
    try {
      if (file.getParentFile() != null && !file.getParentFile().exists()) {
        file.getParentFile().mkdirs();
      }
      if (backupOnSave && file.exists()) {
        rotateBackup();
      }
      data.save(file);
    } catch (Exception ignored) {
      // storage errors must never crash the server thread
    }
  }

  private void rotateBackup() {
    try {
      for (int i = backupKeep; i >= 1; i--) {
        File older = new File(backupDir, file.getName() + ".bak" + i);
        if (older.exists() && i == backupKeep) {
          older.delete();
        } else if (older.exists()) {
          File newer = new File(backupDir, file.getName() + ".bak" + (i + 1));
          older.renameTo(newer);
        }
      }
      File first = new File(backupDir, file.getName() + ".bak1");
      org.bukkit.util.FileUtil.copy(file, first);
    } catch (Exception ignored) {
      // backup failure is non-fatal
    }
  }

  @Override
  public synchronized void touchLogin(UUID uuid) {
    PinRecord record = get(uuid);
    if (record == null) {
      return;
    }
    record.lastLogin(System.currentTimeMillis());
    String base = "pins." + record.uuid();
    data.set(base + ".name", record.name());
    data.set(base + ".last-login", record.lastLogin());
    flush();
    saveIndividualPlayerFile(record);
  }

  @Override
  public void close() {
    flush();
  }
}
