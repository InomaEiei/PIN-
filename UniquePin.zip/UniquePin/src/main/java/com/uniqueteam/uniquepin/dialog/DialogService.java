package com.uniqueteam.uniquepin.dialog;

import com.uniqueteam.uniquepin.config.ConfigManager;
import com.uniqueteam.uniquepin.gui.InventoryPinGui;
import com.uniqueteam.uniquepin.pin.PinSession;
import com.uniqueteam.uniquepin.util.Mini;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.input.DialogInput;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Builds and shows native Dialog UI for every PIN screen.
 *
 * Icon system: Paper Adventure ObjectContents.sprite.
 * Every icon is a genuine vanilla texture from the minecraft:items atlas.
 *
 * All buttons (numbers and actions) share the exact same width so columns
 * align perfectly in a 3-column grid without distortion.
 */
public final class DialogService {

  private final ConfigManager cfg;
  private final boolean spritesAvailable;

  public DialogService(ConfigManager cfg, boolean spritesAvailable) {
    this.cfg = cfg;
    this.spritesAvailable = spritesAvailable;
  }

  /** Real vanilla item texture as an inline text sprite. */
  public static Component itemSprite(String itemPath) {
    String path = (itemPath == null || itemPath.isEmpty()) ? "paper" : itemPath;
    return Component.object(net.kyori.adventure.text.object.ObjectContents.sprite(
        Key.key("minecraft", "items"),
        Key.key("minecraft", "item/" + path)));
  }

  /** Icon and text fused into a single button label Component (icon may be null). */
  public static Component buttonLabel(Component icon, Component text) {
    if (icon == null) {
      return text;
    }
    return Component.text()
        .append(icon)
        .append(Component.space())
        .append(text)
        .build();
  }

  public void show(Player player, PinSession session) {
    if (player == null || !player.isOnline()) {
      return;
    }
    String mode = cfg.guiMode();
    if ("GUI".equalsIgnoreCase(mode)) {
      InventoryPinGui.open(player, session, cfg);
      return;
    }
    try {
      showInner(player, session, spritesAvailable);
      return;
    } catch (Throwable first) {
      // Retrying text-only
    }
    try {
      showInner(player, session, false);
      return;
    } catch (Throwable second) {
      // Paper Dialog API not supported or failed on this platform; fallback to Chest GUI!
      try {
        InventoryPinGui.open(player, session, cfg);
        return;
      } catch (Throwable third) {
        Bukkit.getLogger().severe("[UniquePin] Both Dialog and GUI failed: " + third.getMessage()
            + ". Player " + player.getName() + " must use /pin in chat.");
        try {
          player.sendMessage(Mini.mm("<#FF5555>Dialog ใช้ไม่ได้ ใช้ <#FFFFFF>/pin <พิน></#FFFFFF> ในแชทแทน</#FF5555>"));
        } catch (Throwable ignored) {
        }
      }
    }
  }

  private void showInner(Player player, PinSession session, boolean useSprites) {
    String section = sectionOf(session.mode());
    int length = cfg.pinLength();
    int filled = Math.min(length, session.bufferLength());
    long remainingLockout = session.remainingLockoutSeconds();

    String filledDot = cfg.pinDotFilled();
    String emptyDot = cfg.pinDotEmpty();
    TextColor cFilled = parseColor(cfg.pinDotFilledColor(), TextColor.color(0x3D, 0xFF, 0x77));
    TextColor cEmpty = parseColor(cfg.pinDotEmptyColor(), TextColor.color(0x77, 0x77, 0x77));

    // Construct dots as a pure Adventure Component (NO unparsed raw tags!)
    TextComponent.Builder dotsComp = Component.text();
    for (int i = 0; i < length; i++) {
      if (i > 0) {
        dotsComp.append(Component.space());
      }
      if (i < filled) {
        dotsComp.append(Component.text(filledDot, cFilled).decorate(TextDecoration.BOLD));
      } else {
        dotsComp.append(Component.text(emptyDot, cEmpty));
      }
    }
    Component dotsComponent = dotsComp.build();

    // Plain MiniMessage string for placeholders (100% matched tags)
    String hexFilled = cFilled.asHexString();
    String hexEmpty = cEmpty.asHexString();
    StringBuilder strDots = new StringBuilder();
    for (int i = 0; i < length; i++) {
      if (i > 0) {
        strDots.append(" ");
      }
      if (i < filled) {
        strDots.append("<color:").append(hexFilled).append("><bold>").append(filledDot).append("</bold></color>");
      } else {
        strDots.append("<color:").append(hexEmpty).append(">").append(emptyDot).append("</color>");
      }
    }
    String dotsPlaceholder = strDots.toString();

    Map<String, String> ph = ConfigManager.ph(
        "length", String.valueOf(length),
        "minutes", String.valueOf(cfg.timeoutMinutes()),
        "left", String.valueOf(session.attemptsLeft()),
        "current", String.valueOf(session.bufferLength()),
        "seconds", String.valueOf(remainingLockout),
        "dots", dotsPlaceholder,
        "masked", dotsPlaceholder);

    Component title = Mini.mm(cfg.guiTitle());

    List<DialogBody> bodies = new ArrayList<>();
    // Short description lines
    List<String> descLines = cfg.guiDescription(section, ph);
    List<String> descSprites = cfg.guiStringList(section, "desc-sprites");
    for (int i = 0; i < descLines.size(); i++) {
      Component line = Mini.mm(descLines.get(i));
      String sprite = i < descSprites.size() ? descSprites.get(i) : "";
      Component icon = (useSprites && !sprite.isEmpty()) ? itemSprite(sprite) : null;
      bodies.add(DialogBody.plainMessage(buttonLabel(icon, line)));
    }

    // 6-dots display line with paper sprite (pure Component, guaranteed no tag leaks and no missing texture!)
    Component dotsLine = Component.text()
        .append(Mini.mm(cfg.pinDisplayPrefix()))
        .append(dotsComponent)
        .append(Mini.mm(cfg.pinDisplaySuffix()))
        .build();
    Component dotsIcon = useSprites ? itemSprite(cfg.pinDisplaySprite()) : null;
    bodies.add(DialogBody.plainMessage(buttonLabel(dotsIcon, dotsLine)));

    // Embedded error / lockout line
    String err = session.errorRaw();
    if (err != null && !err.isEmpty()) {
      Component icon = useSprites ? itemSprite("redstone") : null;
      bodies.add(DialogBody.plainMessage(buttonLabel(icon, Mini.mm(err))));
    }
    bodies.add(DialogBody.plainMessage(Mini.mm(cfg.guiCredit())));

    // No dialog input box - dots display replaces it completely
    List<DialogInput> inputs = List.of();

    // Keypad - all buttons use unified cfg.guiButtonWidth() so they align evenly!
    List<ActionButton> actions = new ArrayList<>(14);
    for (int d = 1; d <= 9; d++) {
      actions.add(digitButton(section, d));
    }
    actions.add(spriteButton(section, "clear-label", "clear-tooltip", "button-sprite-clear",
        "<#FF5555>ลบ</#FF5555>", PinDialogKeys.CLEAR, useSprites));
    actions.add(digitButton(section, 0));
    actions.add(spriteButton(section, "back-label", "back-tooltip", "button-sprite-back",
        "<#FFD75F>ย้อน</#FFD75F>", PinDialogKeys.BACK, useSprites));

    // Cancel button (kicks player from server)
    actions.add(spriteButton(section, "cancel-label", "cancel-tooltip", "button-sprite-cancel",
        "<#FF5555>ออก</#FF5555>", PinDialogKeys.CANCEL, useSprites));

    // Repin shortcut lives only on the login screen
    if (session.mode() == PinSession.Mode.LOGIN) {
      actions.add(spriteButton(section, "repin-label", "repin-tooltip", "button-sprite-repin",
          "<#55FFFF>รีพิน</#55FFFF>", PinDialogKeys.REPIN, useSprites));
    }

    DialogBase.DialogAfterAction afterAction;
    if (session.bufferLength() >= cfg.pinLength() - 1) {
      afterAction = DialogBase.DialogAfterAction.CLOSE;
    } else {
      afterAction = DialogBase.DialogAfterAction.WAIT_FOR_RESPONSE;
    }

    Dialog dialog = Dialog.create(builder -> builder.empty()
        .base(DialogBase.builder(title)
            .canCloseWithEscape(cfg.guiCanCloseWithEscape())
            .afterAction(afterAction)
            .body(bodies)
            .inputs(inputs)
            .build())
        .type(DialogType.multiAction(actions, null, cfg.guiColumns())));

    player.showDialog(dialog);
  }

  private ActionButton digitButton(String section, int digit) {
    String num = String.valueOf(digit);
    String labelRaw = cfg.guiText(section, "digit-label", ConfigManager.ph("digit", num));
    if (labelRaw.isEmpty()) {
      labelRaw = "<white><bold>" + num + "</bold></white>";
    }
    String tipRaw = cfg.guiText(section, "digit-tooltip", ConfigManager.ph("digit", num));
    return ActionButton.builder(Mini.mm(labelRaw))
        .tooltip(tipRaw.isEmpty() ? null : Mini.mm(tipRaw))
        .width(cfg.guiButtonWidth())
        .action(DialogAction.customClick(PinDialogKeys.digit(digit), null))
        .build();
  }

  private ActionButton spriteButton(String section, String labelKey, String tipKey,
      String spriteKey, String fallbackLabel, Key action, boolean useSprites) {
    String labelRaw = cfg.guiText(section, labelKey, null);
    if (labelRaw.isEmpty()) {
      labelRaw = cfg.guiText("dialog", labelKey, null);
    }
    if (labelRaw.isEmpty()) {
      labelRaw = fallbackLabel;
    }
    String tipRaw = cfg.guiText(section, tipKey, null);
    if (tipRaw.isEmpty()) {
      tipRaw = cfg.guiText("dialog", tipKey, null);
    }
    String spritePath = cfg.guiText(section, spriteKey, null);
    if (spritePath.isEmpty()) {
      spritePath = cfg.guiText("dialog", spriteKey, null);
    }
    Component icon = useSprites ? itemSprite(spritePath) : null;
    Component label = buttonLabel(icon, Mini.mm(labelRaw));
    return ActionButton.builder(label)
        .tooltip(tipRaw.isEmpty() ? null : Mini.mm(tipRaw))
        .width(cfg.guiButtonWidth())
        .action(DialogAction.customClick(action, null))
        .build();
  }

  public static TextColor parseColor(String hexOrTag, TextColor def) {
    if (hexOrTag == null || hexOrTag.isEmpty()) {
      return def;
    }
    String s = hexOrTag.trim().replace("<", "").replace(">", "").replace("color:", "").replace("/", "");
    if (!s.startsWith("#") && (s.length() == 6 || s.length() == 8)) {
      s = "#" + s;
    }
    try {
      TextColor c = TextColor.fromHexString(s);
      return c != null ? c : def;
    } catch (Exception ex) {
      return def;
    }
  }

  private static String sectionOf(PinSession.Mode mode) {
    if (mode == PinSession.Mode.SETUP_CONFIRM) {
      return "setup-confirm";
    }
    if (mode == PinSession.Mode.LOGIN) {
      return "login";
    }
    if (mode == PinSession.Mode.REPIN_OLD) {
      return "repin-old";
    }
    if (mode == PinSession.Mode.REPIN_NEW) {
      return "repin-new";
    }
    return "setup-step1";
  }
}
