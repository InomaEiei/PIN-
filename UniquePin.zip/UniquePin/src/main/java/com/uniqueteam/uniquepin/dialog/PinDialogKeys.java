package com.uniqueteam.uniquepin.dialog;

import net.kyori.adventure.key.Key;

/**
 * Namespaced custom-click identifiers for every PIN dialog button.
 * Handled server-side in DialogClickListener; unknown keys are ignored.
 */
public final class PinDialogKeys {

  public static final String NAMESPACE = "uniquepin";

  public static final Key CLEAR = Key.key(NAMESPACE, "clear");
  public static final Key BACK = Key.key(NAMESPACE, "back");
  public static final Key CONFIRM = Key.key(NAMESPACE, "confirm");
  public static final Key REPIN = Key.key(NAMESPACE, "repin");
  public static final Key CANCEL = Key.key(NAMESPACE, "cancel");

  /** Dialog text-input key. */
  public static final String INPUT_PIN = "pin";

  private PinDialogKeys() {
  }

  public static Key digit(int d) {
    return Key.key(NAMESPACE, "digit/" + d);
  }

  /** Returns 0-9 for digit keys, or -1 for anything else. */
  public static int parseDigit(Key key) {
    if (key == null || !NAMESPACE.equals(key.namespace())) {
      return -1;
    }
    String value = key.value();
    if (!value.startsWith("digit/") || value.length() != 7) {
      return -1;
    }
    char c = value.charAt(6);
    if (c < '0' || c > '9') {
      return -1;
    }
    return c - '0';
  }
}
