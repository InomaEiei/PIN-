package com.uniqueteam.uniquepin.gui;

import com.uniqueteam.uniquepin.config.ConfigManager;
import com.uniqueteam.uniquepin.dialog.DialogService;
import com.uniqueteam.uniquepin.pin.PinSession;
import com.uniqueteam.uniquepin.util.Mini;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Visual Chest Inventory Keypad GUI.
 * Serves as a 100% reliable fallback whenever native Paper Dialogs are
 * unavailable or fail, guaranteeing players can always enter their PIN smoothly.
 */
public final class InventoryPinGui {

  public static final int SLOT_CLEAR = 39;
  public static final int SLOT_BACK = 41;
  public static final int SLOT_CANCEL = 47;
  public static final int SLOT_REPIN = 51;

  private InventoryPinGui() {
  }

  public static int digitForSlot(int slot) {
    return switch (slot) {
      case 12 -> 1;
      case 13 -> 2;
      case 14 -> 3;
      case 21 -> 4;
      case 22 -> 5;
      case 23 -> 6;
      case 30 -> 7;
      case 31 -> 8;
      case 32 -> 9;
      case 40 -> 0;
      default -> -1;
    };
  }

  public static void open(Player player, PinSession session, ConfigManager cfg) {
    if (player == null || !player.isOnline()) {
      return;
    }

    String section = sectionOf(session.mode());
    int length = cfg.pinLength();
    int filled = Math.min(length, session.bufferLength());
    long remainingLockout = session.remainingLockoutSeconds();

    String filledDot = cfg.pinDotFilled();
    String emptyDot = cfg.pinDotEmpty();
    TextColor cFilled = DialogService.parseColor(cfg.pinDotFilledColor(), TextColor.color(0x3D, 0xFF, 0x77));
    TextColor cEmpty = DialogService.parseColor(cfg.pinDotEmptyColor(), TextColor.color(0x77, 0x77, 0x77));

    TextComponent.Builder dotsComp = Component.text();
    for (int i = 0; i < length; i++) {
      if (i > 0) {
        dotsComp.append(Component.space());
      }
      if (i < filled) {
        dotsComp.append(Component.text(filledDot, cFilled).decorate(TextDecoration.BOLD));
      } else {
        dotsComp.append(Component.text(emptyDot, cEmpty));
      }
    }
    Component dotsComponent = dotsComp.build();

    Map<String, String> ph = ConfigManager.ph(
        "length", String.valueOf(length),
        "minutes", String.valueOf(cfg.timeoutMinutes()),
        "left", String.valueOf(session.attemptsLeft()),
        "current", String.valueOf(session.bufferLength()),
        "seconds", String.valueOf(remainingLockout));

    Component title = Mini.mm(cfg.guiTitle());

    Inventory inv;
    boolean isExisting = false;
    if (player.getOpenInventory().getTopInventory().getHolder() instanceof PinInventoryHolder existingHolder
        && existingHolder.getPlayerId().equals(player.getUniqueId())) {
      inv = player.getOpenInventory().getTopInventory();
      isExisting = true;
    } else {
      PinInventoryHolder holder = new PinInventoryHolder(player.getUniqueId());
      inv = Bukkit.createInventory(holder, 54, title);
      holder.setInventory(inv);
    }

    // Gray glass border
    ItemStack glass = createItem(Material.GRAY_STAINED_GLASS_PANE, 1, Component.space(), null);
    for (int i = 0; i < 54; i++) {
      if (inv.getItem(i) == null || inv.getItem(i).getType() == Material.GRAY_STAINED_GLASS_PANE) {
        inv.setItem(i, glass);
      }
    }

    // Slot 4: Info Display
    List<Component> lore = new ArrayList<>();
    lore.add(Component.empty());
    lore.add(Component.text()
        .append(Mini.mm(cfg.pinDisplayPrefix()))
        .append(dotsComponent)
        .append(Mini.mm(cfg.pinDisplaySuffix()))
        .build());
    lore.add(Component.empty());
    for (String d : cfg.guiDescription(section, ph)) {
      lore.add(Mini.mm(d));
    }
    String err = session.errorRaw();
    if (err != null && !err.isEmpty()) {
      lore.add(Component.empty());
      lore.add(Mini.mm("<#FF5555>⚠ " + err + "</#FF5555>"));
    }
    lore.add(Component.empty());
    lore.add(Mini.mm(cfg.guiCredit()));
    inv.setItem(4, createItem(Material.PAPER, 1, title, lore));

    // Digits 1-9
    int[] digitSlots = {12, 13, 14, 21, 22, 23, 30, 31, 32};
    for (int d = 1; d <= 9; d++) {
      int slot = digitSlots[d - 1];
      Component name = Mini.mm("<#FFFFFF><bold>" + d + "</bold></#FFFFFF>");
      List<Component> digitLore = List.of(Mini.mm("<gray>คลิกเพื่อใส่เลข <#3DFF77>" + d + "</#3DFF77></gray>"));
      inv.setItem(slot, createItem(Material.LIME_DYE, d, name, digitLore));
    }

    // Digit 0 (slot 40)
    Component name0 = Mini.mm("<#FFFFFF><bold>0</bold></#FFFFFF>");
    List<Component> lore0 = List.of(Mini.mm("<gray>คลิกเพื่อใส่เลข <#3DFF77>0</#3DFF77></gray>"));
    inv.setItem(40, createItem(Material.LIME_DYE, 1, name0, lore0));

    // Clear (39)
    String clearLabel = cfg.guiTextFallback(section, "clear-label", "<#FF5555>ลบ</#FF5555>");
    inv.setItem(SLOT_CLEAR, createItem(Material.MILK_BUCKET, 1, Mini.mm(clearLabel),
        List.of(Mini.mm("<gray>ล้างเลขที่กดทั้งหมด</gray>"))));

    // Back (41)
    String backLabel = cfg.guiTextFallback(section, "back-label", "<#FFD75F>ย้อน</#FFD75F>");
    inv.setItem(SLOT_BACK, createItem(Material.ARROW, 1, Mini.mm(backLabel),
        List.of(Mini.mm("<gray>ลบเลขตัวท้ายสุด</gray>"))));

    // Cancel (47)
    String cancelLabel = cfg.guiTextFallback(section, "cancel-label", "<#FF5555>ออก</#FF5555>");
    inv.setItem(SLOT_CANCEL, createItem(Material.BARRIER, 1, Mini.mm(cancelLabel),
        List.of(Mini.mm("<gray>ยกเลิกและออกจากเซิร์ฟเวอร์</gray>"))));

    // Slot 49 - glass
    inv.setItem(49, glass);

    // Repin (51) - LOGIN mode only
    if (session.mode() == PinSession.Mode.LOGIN) {
      String repinLabel = cfg.guiTextFallback(section, "repin-label", "<#55FFFF>รีพิน</#55FFFF>");
      inv.setItem(SLOT_REPIN, createItem(Material.WRITABLE_BOOK, 1, Mini.mm(repinLabel),
          List.of(Mini.mm("<gray>เปลี่ยนรหัสพิน</gray>"))));
    } else {
      inv.setItem(SLOT_REPIN, glass);
    }

    if (!isExisting) {
      player.openInventory(inv);
    }
  }

  private static ItemStack createItem(Material mat, int amount, Component name, List<Component> lore) {
    ItemStack item = new ItemStack(mat, Math.max(1, Math.min(64, amount)));
    ItemMeta meta = item.getItemMeta();
    if (meta != null) {
      if (name != null) {
        meta.displayName(name);
      }
      if (lore != null) {
        meta.lore(lore);
      }
      item.setItemMeta(meta);
    }
    return item;
  }

  private static String sectionOf(PinSession.Mode mode) {
    if (mode == PinSession.Mode.SETUP_CONFIRM) {
      return "setup-confirm";
    }
    if (mode == PinSession.Mode.LOGIN) {
      return "login";
    }
    if (mode == PinSession.Mode.REPIN_OLD) {
      return "repin-old";
    }
    if (mode == PinSession.Mode.REPIN_NEW) {
      return "repin-new";
    }
    return "setup-step1";
  }
}
