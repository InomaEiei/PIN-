package com.uniqueteam.uniquepin.gui;

import com.uniqueteam.uniquepin.pin.PinManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public final class InventoryPinListener implements Listener {

  private final PinManager pins;

  public InventoryPinListener(PinManager pins) {
    this.pins = pins;
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void onClick(InventoryClickEvent event) {
    if (!(event.getWhoClicked() instanceof Player player)) {
      return;
    }
    if (event.getInventory().getHolder() instanceof PinInventoryHolder) {
      event.setCancelled(true);
      if (event.getClickedInventory() != event.getView().getTopInventory()) {
        return;
      }
      int slot = event.getSlot();
      int digit = InventoryPinGui.digitForSlot(slot);
      if (digit >= 0) {
        pins.pressDigit(player, digit);
        return;
      }
      if (slot == InventoryPinGui.SLOT_CLEAR) {
        pins.pressClear(player);
        return;
      }
      if (slot == InventoryPinGui.SLOT_BACK) {
        pins.pressBack(player);
        return;
      }
      if (slot == InventoryPinGui.SLOT_CANCEL) {
        pins.pressCancel(player);
        return;
      }
      if (slot == InventoryPinGui.SLOT_REPIN) {
        pins.pressRepin(player);
        return;
      }
    }
  }

  @EventHandler(priority = EventPriority.HIGHEST)
  public void onDrag(InventoryDragEvent event) {
    if (event.getInventory().getHolder() instanceof PinInventoryHolder) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onClose(InventoryCloseEvent event) {
    if (!(event.getPlayer() instanceof Player player)) {
      return;
    }
    if (event.getInventory().getHolder() instanceof PinInventoryHolder) {
      if (pins.isLocked(player.getUniqueId())) {
        pins.scheduleFastReopen(player);
      }
    }
  }
}
