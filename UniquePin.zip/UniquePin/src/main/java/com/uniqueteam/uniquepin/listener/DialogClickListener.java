package com.uniqueteam.uniquepin.listener;

import com.uniqueteam.uniquepin.dialog.PinDialogKeys;
import com.uniqueteam.uniquepin.pin.PinManager;
import com.uniqueteam.uniquepin.pin.PinSession;
import io.papermc.paper.connection.PlayerGameConnection;
import io.papermc.paper.dialog.DialogResponseView;
import io.papermc.paper.event.player.PlayerCustomClickEvent;
import net.kyori.adventure.key.Key;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

/**
 * Routes native dialog button clicks to the server-side PIN state machine.
 * Unknown identifiers and clicks from unlocked players are ignored, so
 * forged packets from hack clients cannot do anything useful.
 */
public final class DialogClickListener implements Listener {

  private final PinManager pins;

  public DialogClickListener(PinManager pins) {
    this.pins = pins;
  }

  @EventHandler(priority = EventPriority.NORMAL)
  public void onCustomClick(PlayerCustomClickEvent event) {
    if (!(event.getCommonConnection() instanceof PlayerGameConnection)) {
      return;
    }
    PlayerGameConnection connection = (PlayerGameConnection) event.getCommonConnection();
    Player player;
    try {
      player = connection.getPlayer();
    } catch (Exception ex) {
      return;
    }
    if (player == null || !player.isOnline()) {
      return;
    }
    PinSession session = pins.get(player.getUniqueId());
    if (session == null) {
      return; // not locked: ignore dialog packets entirely
    }
    Key id = event.getIdentifier();
    int digit = PinDialogKeys.parseDigit(id);
    if (digit >= 0) {
      pins.pressDigit(player, digit);
      return;
    }
    if (PinDialogKeys.CLEAR.equals(id)) {
      pins.pressClear(player);
      return;
    }
    if (PinDialogKeys.BACK.equals(id)) {
      pins.pressBack(player);
      return;
    }
    if (PinDialogKeys.REPIN.equals(id)) {
      pins.pressRepin(player);
      return;
    }
    if (PinDialogKeys.CANCEL.equals(id)) {
      pins.pressCancel(player);
      return;
    }
    if (PinDialogKeys.CONFIRM.equals(id)) {
      pins.confirm(player, "");
      return;
    }
    // Any other key: ignored (never trust the client).
  }
}
