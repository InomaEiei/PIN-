package com.uniqueteam.uniquepin.listener;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import com.uniqueteam.uniquepin.config.ConfigManager;
import com.uniqueteam.uniquepin.pin.PinManager;
import com.uniqueteam.uniquepin.util.SchedulerUtil;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import com.destroystokyo.paper.event.server.AsyncTabCompleteEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerEditBookEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPortalEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

/**
 * Server-side lock enforcement. Every action a locked player could use to
 * play without a PIN (including hack-client tricks like closing the dialog,
 * teleport packets, ender pearls, gamemode or flight abuse) is cancelled
 * here. The lock never depends on the dialog being open.
 */
@SuppressWarnings("deprecation")
public final class LockListener implements Listener {

  private final UniquePinPlugin plugin;
  private final ConfigManager cfg;
  private final PinManager pins;

  public LockListener(UniquePinPlugin plugin, ConfigManager cfg, PinManager pins) {
    this.plugin = plugin;
    this.cfg = cfg;
    this.pins = pins;
  }

  // ---------- join / quit (NO session: state is always fresh) ----------

  @EventHandler(priority = EventPriority.NORMAL)
  public void onJoin(PlayerJoinEvent event) {
    Player player = event.getPlayer();
    if (pins.isBedrockExempt(player)) {
      pins.cleanupPlayer(player);
      player.sendMessage(cfg.msg("bedrock-exempt"));
      return;
    }
    pins.applyFreeze(player);
    SchedulerUtil.runOnEntityLater(plugin, player, cfg.joinDelayTicks(), () -> {
      if (!player.isOnline()) {
        return;
      }
      if (pins.isBedrockExempt(player)) {
        pins.cleanupPlayer(player);
        player.sendMessage(cfg.msg("bedrock-exempt"));
        return;
      }
      pins.startSession(player);
    });
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onQuit(PlayerQuitEvent event) {
    pins.cleanupPlayer(event.getPlayer());
  }

  @EventHandler(priority = EventPriority.MONITOR)
  public void onKick(PlayerKickEvent event) {
    pins.cleanupPlayer(event.getPlayer());
  }

  // ---------- movement ----------

  @EventHandler(priority = EventPriority.LOWEST)
  public void onMove(PlayerMoveEvent event) {
    Player player = event.getPlayer();
    if (!pins.isLocked(player.getUniqueId()) || !cfg.lock("move")) {
      return;
    }
    double dx = Math.abs(event.getTo().getX() - event.getFrom().getX());
    double dz = Math.abs(event.getTo().getZ() - event.getFrom().getZ());
    boolean isJumping = event.getTo().getY() > event.getFrom().getY();
    boolean allowFalling = cfg.lock("allow-falling");

    if (dx > 0.0001 || dz > 0.0001 || isJumping) {
      if (allowFalling && !isJumping) {
        org.bukkit.Location to = event.getTo().clone();
        to.setX(event.getFrom().getX());
        to.setZ(event.getFrom().getZ());
        event.setTo(to);
      } else {
        event.setCancelled(true);
      }
      // Re-show dialog immediately if movement or teleport packet caused client dialog to dismiss
      pins.scheduleFastReopen(player);
      return;
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onVelocity(org.bukkit.event.player.PlayerVelocityEvent event) {
    if (pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onVehicleEnter(org.bukkit.event.vehicle.VehicleEnterEvent event) {
    if (event.getEntered() instanceof Player player && pins.isLocked(player.getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onSprint(org.bukkit.event.player.PlayerToggleSprintEvent event) {
    if (pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onSneak(org.bukkit.event.player.PlayerToggleSneakEvent event) {
    if (pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onTeleport(PlayerTeleportEvent event) {
    if (cfg.lock("teleport") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onPortal(PlayerPortalEvent event) {
    if (cfg.lock("portal") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onBedEnter(PlayerBedEnterEvent event) {
    if (cfg.lock("bed-enter") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onToggleFlight(PlayerToggleFlightEvent event) {
    if (cfg.lock("toggle-flight") && pins.isLocked(event.getPlayer().getUniqueId())
        && event.isFlying()) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onGameModeChange(PlayerGameModeChangeEvent event) {
    if (pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  // ---------- chat / commands ----------

  @EventHandler(priority = EventPriority.LOWEST)
  public void onChat(AsyncPlayerChatEvent event) {
    if (cfg.lock("chat") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
      event.getPlayer().sendMessage(cfg.msg("blocked-chat"));
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onPaperChat(io.papermc.paper.event.player.AsyncChatEvent event) {
    if (cfg.lock("chat") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
      event.getPlayer().sendMessage(cfg.msg("blocked-chat"));
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onCommand(PlayerCommandPreprocessEvent event) {
    if (!pins.isLocked(event.getPlayer().getUniqueId())) {
      return;
    }
    String lower = event.getMessage().toLowerCase();
    for (String allowed : cfg.allowedCommands()) {
      if (lower.equals(allowed) || lower.startsWith(allowed + " ")) {
        return;
      }
    }
    event.setCancelled(true);
    event.getPlayer().sendMessage(cfg.msg("blocked-command"));
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onTabComplete(AsyncTabCompleteEvent event) {
    if (!(event.getSender() instanceof Player)) {
      return;
    }
    Player player = (Player) event.getSender();
    if (cfg.lock("tab-complete") && pins.isLocked(player.getUniqueId())) {
      event.setCompletions(List.of());
    }
  }

  // ---------- interaction / world ----------

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInteract(PlayerInteractEvent event) {
    if (cfg.lock("interact") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInteractEntity(PlayerInteractEntityEvent event) {
    if (cfg.lock("interact") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInteractAtEntity(PlayerInteractAtEntityEvent event) {
    if (cfg.lock("interact") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onBreak(BlockBreakEvent event) {
    if (cfg.lock("break-block") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onPlace(BlockPlaceEvent event) {
    if (cfg.lock("place-block") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onFish(PlayerFishEvent event) {
    if (cfg.lock("interact") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onEditBook(PlayerEditBookEvent event) {
    if (cfg.lock("edit-book") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onConsume(PlayerItemConsumeEvent event) {
    if (cfg.lock("interact") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onProjectile(ProjectileLaunchEvent event) {
    if (event.getEntity().getShooter() instanceof Player
        && cfg.lock("interact")
        && pins.isLocked(((Player) event.getEntity().getShooter()).getUniqueId())) {
      event.setCancelled(true);
    }
  }

  // ---------- damage / hunger ----------

  @EventHandler(priority = EventPriority.LOWEST)
  public void onDamage(EntityDamageEvent event) {
    if (!(event.getEntity() instanceof Player)) {
      return;
    }
    if (cfg.lock("damage-incoming")
        && pins.isLocked(event.getEntity().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onDamageByEntity(EntityDamageByEntityEvent event) {
    if (event.getDamager() instanceof Player
        && cfg.lock("damage-outgoing")
        && pins.isLocked(event.getDamager().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onHunger(FoodLevelChangeEvent event) {
    if (event.getEntity() instanceof Player
        && cfg.lock("hunger")
        && pins.isLocked(event.getEntity().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  // ---------- inventory / items ----------

  @EventHandler(priority = EventPriority.LOWEST)
  public void onDrop(PlayerDropItemEvent event) {
    if (cfg.lock("drop-item") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onPickup(EntityPickupItemEvent event) {
    if (event.getEntity() instanceof Player
        && cfg.lock("pickup-item")
        && pins.isLocked(event.getEntity().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInventoryClick(InventoryClickEvent event) {
    if (event.getWhoClicked() instanceof Player
        && cfg.lock("inventory-click")
        && pins.isLocked(event.getWhoClicked().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInventoryDrag(InventoryDragEvent event) {
    if (event.getWhoClicked() instanceof Player
        && cfg.lock("inventory-click")
        && pins.isLocked(event.getWhoClicked().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onInventoryOpen(InventoryOpenEvent event) {
    if (event.getPlayer() instanceof Player
        && cfg.lock("inventory-open")
        && pins.isLocked(event.getPlayer().getUniqueId())) {
      if (event.getInventory().getHolder() instanceof com.uniqueteam.uniquepin.gui.PinInventoryHolder) {
        return;
      }
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onSwapHand(PlayerSwapHandItemsEvent event) {
    if (cfg.lock("swap-hand") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }

  @EventHandler(priority = EventPriority.LOWEST)
  public void onHeldSlot(PlayerItemHeldEvent event) {
    if (cfg.lock("change-held-slot") && pins.isLocked(event.getPlayer().getUniqueId())) {
      event.setCancelled(true);
    }
  }
}
