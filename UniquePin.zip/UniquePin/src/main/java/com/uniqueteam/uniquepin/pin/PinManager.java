package com.uniqueteam.uniquepin.pin;

import com.uniqueteam.uniquepin.UniquePinPlugin;
import com.uniqueteam.uniquepin.config.ConfigManager;
import com.uniqueteam.uniquepin.data.PinRecord;
import com.uniqueteam.uniquepin.data.PinStorage;
import com.uniqueteam.uniquepin.data.YamlPinStorage;
import com.uniqueteam.uniquepin.dialog.DialogService;
import com.uniqueteam.uniquepin.util.HashUtil;
import com.uniqueteam.uniquepin.util.SchedulerUtil;
import com.uniqueteam.uniquepin.util.SoundUtil;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

/**
 * Server-authoritative PIN state machine.
 * The client dialog is only a remote control: every digit, confirm and
 * unlock decision is validated here. Hack clients cannot bypass because
 * movement, chat, commands and interactions are locked independently of
 * any dialog packet.
 */
public final class PinManager {

  private final UniquePinPlugin plugin;
  private final ConfigManager cfg;
  private final PinStorage storage;
  private final DialogService dialogs;

  private final Map<UUID, PinSession> sessions = new ConcurrentHashMap<>();
  private final Set<UUID> pendingFreeze = ConcurrentHashMap.newKeySet();
  private final Map<UUID, Long> lockouts = new ConcurrentHashMap<>();

  public PinManager(UniquePinPlugin plugin, ConfigManager cfg, PinStorage storage, DialogService dialogs) {
    this.plugin = plugin;
    this.cfg = cfg;
    this.storage = storage;
    this.dialogs = dialogs;
  }

  // ---------- session lifecycle ----------

  /** Called on join (main thread). Freezes instantly, resolves PIN state async. */
  public void startSession(Player player) {
    if (player == null || !player.isOnline()) {
      return;
    }
    if (isBedrockExempt(player)) {
      cleanupPlayer(player);
      send(player, cfg.msg("bedrock-exempt"));
      return;
    }
    UUID id = player.getUniqueId();
    if (sessions.containsKey(id)) {
      openDialog(player);
      return;
    }
    if (pendingFreeze.contains(id)) {
      return;
    }
    float walk;
    boolean allowFlight;
    boolean flying;
    float flySpeed;
    boolean collidable;
    try {
      walk = player.getWalkSpeed();
    } catch (Exception ex) {
      walk = 0.2f;
    }
    if (walk < 0.19f || Float.isNaN(walk)) {
      walk = 0.2f;
    }
    try {
      allowFlight = player.getAllowFlight();
    } catch (Exception ex) {
      allowFlight = false;
    }
    try {
      flying = player.isFlying();
    } catch (Exception ex) {
      flying = false;
    }
    try {
      flySpeed = player.getFlySpeed();
    } catch (Exception ex) {
      flySpeed = 0.1f;
    }
    if (flySpeed < 0.05f || Float.isNaN(flySpeed)) {
      flySpeed = 0.1f;
    }
    try {
      collidable = player.isCollidable();
    } catch (Exception ex) {
      collidable = true;
    }
    moveBackup.put(id, new float[]{walk, allowFlight ? 1.0f : 0.0f, flying ? 1.0f : 0.0f, flySpeed, collidable ? 1.0f : 0.0f});
    pendingFreeze.add(id);
    applyFreeze(player);
    final float savedWalk = walk;
    final boolean savedAllow = allowFlight;
    final boolean savedFlying = flying;
    final float savedFly = flySpeed;
    final boolean savedCollidable = collidable;
    SchedulerUtil.runAsync(plugin, () -> {
      boolean has;
      try {
        has = storage.hasPin(id);
      } catch (Exception ex) {
        has = false;
      }
      final boolean hasPin = has;
      Player online = Bukkit.getPlayer(id);
      if (online == null || !online.isOnline()) {
        pendingFreeze.remove(id);
        return;
      }
      SchedulerUtil.runOnEntity(plugin, online, () -> {
        pendingFreeze.remove(id);
        if (!online.isOnline()) {
          return;
        }
        PinSession.Mode mode = hasPin ? PinSession.Mode.LOGIN : PinSession.Mode.SETUP_STEP1;
        Long lockoutUntil = lockouts.get(id);
        long now = System.currentTimeMillis();
        long activeLockoutUntil = 0L;
        int initialAttempts = cfg.maxAttempts();
        if (lockoutUntil != null) {
          if (now < lockoutUntil) {
            activeLockoutUntil = lockoutUntil;
            initialAttempts = 0;
          } else {
            lockouts.remove(id);
          }
        }
        PinSession session = new PinSession(id, mode, initialAttempts);
        if (activeLockoutUntil > 0L) {
          session.lockoutUntil(activeLockoutUntil);
          long remainingSec = (activeLockoutUntil - now + 999L) / 1000L;
          session.errorRaw(cfg.rawMsg("dlg-locked-out", ConfigManager.ph("seconds", String.valueOf(remainingSec))));
        }
        session.captureState(savedWalk, savedAllow, savedFlying, savedFly, savedCollidable);
        sessions.put(id, session);
        debug("locked " + online.getName() + " mode=" + mode);
        sendChatPrompt(online);
        openDialog(online);
      });
    });
  }

  public void pressCancel(Player player) {
    if (player == null) {
      return;
    }
    cleanupPlayer(player);
    playSound(player, "back", "block.note_block.bass", 0.6f, 0.7f);
    kick(player, cfg.msg("cancel-kick"));
  }

  public void cleanupPlayer(Player player) {
    if (player == null) {
      return;
    }
    UUID id = player.getUniqueId();
    PinSession session = sessions.remove(id);
    pendingFreeze.remove(id);
    frozen.remove(id);
    moveBackup.remove(id);
    restoreMovement(player, session);
    try {
      player.removePotionEffect(PotionEffectType.SLOWNESS);
      player.removePotionEffect(PotionEffectType.DARKNESS);
      if (player.getWalkSpeed() < 0.19f) {
        player.setWalkSpeed(0.2f);
      }
      player.setCollidable(true);
    } catch (Exception ignored) {
    }
  }

  public void endSession(UUID uuid) {
    sessions.remove(uuid);
    pendingFreeze.remove(uuid);
    moveBackup.remove(uuid);
  }

  public boolean isLocked(UUID uuid) {
    return sessions.containsKey(uuid) || pendingFreeze.contains(uuid);
  }

  public PinSession get(UUID uuid) {
    return sessions.get(uuid);
  }

  public void openDialog(Player player) {
    if (player == null || !player.isOnline()) {
      return;
    }
    UUID id = player.getUniqueId();
    PinSession session = sessions.get(id);
    if (session == null) {
      if (isLocked(id)) {
        startSession(player);
      }
      return;
    }
    SchedulerUtil.runOnEntity(plugin, player, () -> {
      if (player.isOnline() && sessions.containsKey(id)) {
        session.lastDialogOpen(System.currentTimeMillis());
        dialogs.show(player, session);
      }
    });
  }

  /**
   * Fast reopen when player is moved, bumped or client closes dialog.
   * Debounced to 200ms to prevent spamming packets, delayed by 1 tick
   * so client position sync finishes first.
   */
  public void scheduleFastReopen(Player player) {
    if (player == null || !player.isOnline()) {
      return;
    }
    UUID id = player.getUniqueId();
    PinSession session = sessions.get(id);
    if (session == null) {
      if (isLocked(id)) {
        startSession(player);
      }
      return;
    }
    if (session.busy()) {
      return;
    }
    long now = System.currentTimeMillis();
    if (now - session.lastReopenScheduled() < 200L) {
      return;
    }
    session.lastReopenScheduled(now);
    SchedulerUtil.runOnEntityLater(plugin, player, 1L, () -> {
      if (player.isOnline() && sessions.containsKey(id)) {
        openDialog(player);
        sendChatPrompt(player);
      }
    });
  }

  // ---------- keypad input ----------

  public void pressDigit(Player player, int digit) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy() || !session.tryClick(cfg.maxClicksPerSecond())) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    if (digit < 0 || digit > 9) {
      return;
    }
    if (!session.appendDigit((char) ('0' + digit), cfg.pinLength())) {
      // Already full: submit instead of redrawing the same screen.
      confirmInternal(player, "", false);
      return;
    }
    session.errorRaw("");
    playDigitSound(player, session);
    if (session.bufferLength() >= cfg.pinLength()) {
      // Correct length reached: go immediately, no confirm press needed.
      confirmInternal(player, "", false);
      return;
    }
    dialogs.show(player, session);
    session.lastDialogOpen(System.currentTimeMillis());
  }

  public void pressRepin(Player player) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy() || !session.tryClick(cfg.maxClicksPerSecond())) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    if (session.mode() != PinSession.Mode.LOGIN) {
      return;
    }
    session.mode(PinSession.Mode.REPIN_OLD);
    session.clearBuffer();
    session.errorRaw("");
    session.repinOld("");
    playSound(player, "step", "block.note_block.bit", 0.6f, 1.0f);
    dialogs.show(player, session);
    session.lastDialogOpen(System.currentTimeMillis());
  }

  public void pressBack(Player player) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy() || !session.tryClick(cfg.maxClicksPerSecond())) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    if (!session.backspace()) {
      return; // nothing changed: skip redraw for smoothness
    }
    session.errorRaw("");
    playSound(player, "back", "block.note_block.bass", 0.5f, 0.9f);
    dialogs.show(player, session);
    session.lastDialogOpen(System.currentTimeMillis());
  }

  public void pressClear(Player player) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy() || !session.tryClick(cfg.maxClicksPerSecond())) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    if (session.bufferLength() == 0) {
      return; // nothing changed: skip redraw for smoothness
    }
    session.clearBuffer();
    session.errorRaw("");
    playSound(player, "clear", "block.note_block.bass", 0.5f, 0.7f);
    dialogs.show(player, session);
    session.lastDialogOpen(System.currentTimeMillis());
  }

  /**
   * Confirm button (or /pin command path uses confirmPinCommand below).
   * typedText is the raw dialog input; with keypad-authoritative mode the
   * server-side buffer is the only accepted source (typed text is ignored),
   * so typing into the field can never inject a PIN.
   */
  public void confirm(Player player, String typedText) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy()) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    confirmInternal(player, typedText, true);
  }

  private void confirmInternal(Player player, String typedText, boolean countClick) {
    PinSession session = sessions.get(player.getUniqueId());
    if (session == null || session.busy()) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.5f, 0.6f);
      return;
    }
    if (countClick && !session.tryClick(cfg.maxClicksPerSecond())) {
      return;
    }
    String typed = typedText == null ? "" : typedText.trim();
    String buffer = session.buffer();
    String candidate;
    if (cfg.keypadAuthoritative()) {
      candidate = buffer;
    } else {
      candidate = isFormatOk(typed) ? typed : buffer;
    }
    PinSession.Mode mode = session.mode();
    if (!isFormatOk(candidate)) {
      // Invalid entry counts as a failed login attempt (anti-probing).
      if (mode == PinSession.Mode.LOGIN || mode == PinSession.Mode.REPIN_OLD) {
        failLogin(player, session);
      } else {
        dialogError(player, session, "setup-invalid", "dlg-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
        session.clearBuffer();
        openDialog(player);
      }
      return;
    }
    // Memory-only modes confirm instantly: correct goes immediately,
    // wrong stays on screen for correction (no pointless waiting).
    if (mode == PinSession.Mode.SETUP_STEP1) {
      session.step1Pin(candidate);
      session.clearBuffer();
      session.errorRaw("");
      session.mode(PinSession.Mode.SETUP_CONFIRM);
      send(player, cfg.msg("setup-need-confirm"));
      playSound(player, "step", "block.note_block.bit", 0.6f, 1.0f);
      openDialog(player);
      return;
    }
    if (mode == PinSession.Mode.SETUP_CONFIRM) {
      if (candidate.equals(session.step1Pin())) {
        persistAndUnlock(player, session, candidate, cfg.msg("setup-success"), false);
      } else {
        session.clearBuffer();
        dialogError(player, session, "setup-mismatch", "dlg-mismatch", null);
        openDialog(player);
      }
      return;
    }
    if (mode == PinSession.Mode.REPIN_NEW) {
      if (candidate.equals(session.repinOld())) {
        session.clearBuffer();
        dialogError(player, session, "repin-same", "dlg-same", null);
        openDialog(player);
        return;
      }
      persistAndUnlock(player, session, candidate, cfg.msg("repin-success"), false);
      return;
    }
    session.busy(true);
    final String pin = candidate;
    SchedulerUtil.runAsync(plugin, () -> {
      if (cfg.verifyDelayMs() > 0) {
        try {
          Thread.sleep(cfg.verifyDelayMs());
        } catch (InterruptedException ignored) {
          Thread.currentThread().interrupt();
        }
      }
      SchedulerUtil.runOnEntity(plugin, player, () -> {
        try {
          applyConfirm(player, session, mode, pin);
        } finally {
          PinSession current = sessions.get(player.getUniqueId());
          if (current == session) {
            session.busy(false);
          } else {
            session.busy(false);
          }
        }
      });
    });
  }

  /** Saves the PIN off-thread, then unlocks. Never leaves busy stuck. */
  private void persistAndUnlock(Player player, PinSession session, String pin,
      Component successMsg, boolean paced) {
    session.busy(true);
    SchedulerUtil.runAsync(plugin, () -> {
      if (paced && cfg.verifyDelayMs() > 0) {
        try {
          Thread.sleep(cfg.verifyDelayMs());
        } catch (InterruptedException ex) {
          Thread.currentThread().interrupt();
        }
      }
      setPin(player.getUniqueId(), player.getName(), pin);
      SchedulerUtil.runOnEntity(plugin, player, () -> {
        try {
          session.busy(false);
          if (!player.isOnline() || sessions.get(player.getUniqueId()) != session) {
            return;
          }
          playSound(player, "success", "block.note_block.pling", 0.8f, 1.4f);
          unlock(player, successMsg);
        } catch (Throwable t) {
          session.busy(false);
          plugin.getLogger().warning("Unlock failed for " + player.getName() + ": " + t.getMessage());
        }
      });
    });
  }

  private void applyConfirm(Player player, PinSession session, PinSession.Mode mode, String pin) {
    if (!player.isOnline() || sessions.get(player.getUniqueId()) != session) {
      return;
    }
    // SETUP_STEP1 / SETUP_CONFIRM / REPIN_NEW are handled instantly in
    // confirmInternal (in-memory compare). Only storage modes reach here.
    if (mode == PinSession.Mode.REPIN_OLD) {
      PinRecord oldRecord;
      try {
        oldRecord = storage.get(player.getUniqueId());
      } catch (Exception ex) {
        oldRecord = null;
      }
      boolean oldOk = oldRecord != null
          && HashUtil.verify(cfg.hashAlgorithm(), oldRecord.salt(), pin, oldRecord.hash());
      if (oldOk) {
        session.repinOld(pin);
        session.clearBuffer();
        session.errorRaw("");
        session.mode(PinSession.Mode.REPIN_NEW);
        playSound(player, "step", "block.note_block.bit", 0.6f, 1.0f);
        openDialog(player);
      } else {
        failLogin(player, session);
      }
      return;
    }
    // LOGIN
    PinRecord record;
    try {
      record = storage.get(player.getUniqueId());
    } catch (Exception ex) {
      record = null;
    }
    boolean ok = record != null && HashUtil.verify(cfg.hashAlgorithm(), record.salt(), pin, record.hash());
    if (ok) {
      playSound(player, "success", "block.note_block.pling", 0.8f, 1.4f);
      unlock(player, cfg.msg("login-success"));
    } else {
      failLogin(player, session);
    }
  }

  private void failLogin(Player player, PinSession session) {
    int left = session.attemptsLeft() - 1;
    session.attemptsLeft(left);
    session.clearBuffer();
    if (left <= 0) {
      long lockoutSec = cfg.lockoutSeconds();
      long lockoutUntil = System.currentTimeMillis() + (lockoutSec * 1000L);
      lockouts.put(player.getUniqueId(), lockoutUntil);
      session.lockoutUntil(lockoutUntil);
      session.errorRaw(cfg.rawMsg("dlg-locked-out", ConfigManager.ph("seconds", String.valueOf(lockoutSec))));
      send(player, cfg.msg("login-locked-out", ConfigManager.ph("seconds", String.valueOf(lockoutSec))));
      playSound(player, "error", "block.note_block.didgeridoo", 0.6f, 0.7f);
      openDialog(player);
      return;
    }
    dialogError(player, session, "login-wrong", "dlg-wrong",
        ConfigManager.ph("left", String.valueOf(left)));
    openDialog(player);
  }

  /**
   * Shows an error both in chat and embedded in the dialog (with a leading
   * vanilla sprite), plus a sci-fi error sound. The dialog error clears on
   * the next keypad press.
   */
  private void dialogError(Player player, PinSession session,
      String chatKey, String dlgKey, Map<String, String> placeholders) {
    Map<String, String> ph = placeholders == null ? Map.of() : placeholders;
    send(player, cfg.msg(chatKey, ph));
    session.errorRaw(cfg.rawMsg(dlgKey, ph));
    playSound(player, "error", "block.note_block.didgeridoo", 0.6f, 0.7f);
  }

  private void playSound(Player player, String name, String defType, float defVol, float defPitch) {
    if (!cfg.soundsEnabled()) {
      return;
    }
    SoundUtil.play(player, cfg.soundType(name, defType),
        cfg.soundVolume(name, defVol), cfg.soundPitch(name, defPitch));
  }

  private void playDigitSound(Player player, PinSession session) {
    if (!cfg.soundsEnabled()) {
      return;
    }
    float pitch = cfg.soundBasePitch() + cfg.soundPitchStep() * session.bufferLength();
    SoundUtil.play(player, cfg.soundType("digit", "block.note_block.bit"),
        cfg.soundVolume("digit", 0.6f), pitch);
  }

  // ---------- /pin command path (typed, server-validated) ----------

  public void confirmPinCommand(Player player, String pin, String confirmOrNull) {
    UUID id = player.getUniqueId();
    PinSession existing = sessions.get(id);
    if (existing == null) {
      if (!isLocked(id)) {
        send(player, cfg.msg("already-unlocked"));
        return;
      }
      startSession(player);
      existing = sessions.get(id);
      if (existing == null) {
        send(player, cfg.msg("usage-pin"));
        return;
      }
    }
    final PinSession session = existing;
    if (session.busy()) {
      return;
    }
    if (session.isLockedOut()) {
      long sec = session.remainingLockoutSeconds();
      send(player, cfg.msg("lockout-waiting", ConfigManager.ph("seconds", String.valueOf(sec))));
      return;
    }
    PinSession.Mode mode = session.mode();
    if (mode == PinSession.Mode.LOGIN) {
      if (!isFormatOk(pin)) {
        failLogin(player, session);
        return;
      }
      session.busy(true);
      SchedulerUtil.runAsync(plugin, () -> {
        boolean ok;
        try {
          PinRecord record = storage.get(player.getUniqueId());
          ok = record != null && HashUtil.verify(cfg.hashAlgorithm(), record.salt(), pin, record.hash());
        } catch (Exception ex) {
          ok = false;
        }
        final boolean result = ok;
        SchedulerUtil.runOnEntity(plugin, player, () -> {
          session.busy(false);
          if (!player.isOnline() || sessions.get(player.getUniqueId()) != session) {
            return;
          }
          if (result) {
            playSound(player, "success", "block.note_block.pling", 0.8f, 1.4f);
            unlock(player, cfg.msg("login-success"));
          } else {
            failLogin(player, session);
          }
        });
      });
      return;
    }
    // REPIN modes via command (typed old/new PIN, same rules as dialog).
    if (mode == PinSession.Mode.REPIN_OLD) {
      if (!isFormatOk(pin)) {
        failLogin(player, session);
        return;
      }
      session.busy(true);
      SchedulerUtil.runAsync(plugin, () -> {
        boolean ok;
        try {
          PinRecord record = storage.get(player.getUniqueId());
          ok = record != null && HashUtil.verify(cfg.hashAlgorithm(), record.salt(), pin, record.hash());
        } catch (Exception ex) {
          ok = false;
        }
        final boolean result = ok;
        SchedulerUtil.runOnEntity(plugin, player, () -> {
          session.busy(false);
          if (!player.isOnline() || sessions.get(player.getUniqueId()) != session) {
            return;
          }
          if (result) {
            session.repinOld(pin);
            session.clearBuffer();
            session.errorRaw("");
            session.mode(PinSession.Mode.REPIN_NEW);
            playSound(player, "step", "block.note_block.bit", 0.6f, 1.0f);
            openDialog(player);
          } else {
            failLogin(player, session);
          }
        });
      });
      return;
    }
    if (mode == PinSession.Mode.REPIN_NEW) {
      if (!isFormatOk(pin)) {
        dialogError(player, session, "setup-invalid", "dlg-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
        openDialog(player);
        return;
      }
      if (pin.equals(session.repinOld())) {
        dialogError(player, session, "repin-same", "dlg-same", null);
        openDialog(player);
        return;
      }
      persistAndUnlock(player, session, pin, cfg.msg("repin-success"), false);
      return;
    }
    // SETUP_STEP1: first entry of new PIN
    if (mode == PinSession.Mode.SETUP_STEP1) {
      if (confirmOrNull != null) {
        if (!isFormatOk(pin)) {
          dialogError(player, session, "setup-invalid", "dlg-invalid",
              ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
          openDialog(player);
          return;
        }
        if (!pin.equals(confirmOrNull)) {
          dialogError(player, session, "setup-mismatch", "dlg-mismatch", null);
          openDialog(player);
          return;
        }
        persistAndUnlock(player, session, pin, cfg.msg("setup-success"), false);
        return;
      }
      if (!isFormatOk(pin)) {
        dialogError(player, session, "setup-invalid", "dlg-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
        openDialog(player);
        return;
      }
      session.step1Pin(pin);
      session.clearBuffer();
      session.errorRaw("");
      session.mode(PinSession.Mode.SETUP_CONFIRM);
      send(player, cfg.msg("setup-need-confirm"));
      playSound(player, "step", "block.note_block.bit", 0.6f, 1.0f);
      openDialog(player);
      return;
    }
    // SETUP_CONFIRM: confirming the PIN previously entered
    if (mode == PinSession.Mode.SETUP_CONFIRM) {
      String expected = session.step1Pin();
      if (confirmOrNull != null) {
        if (!isFormatOk(pin)) {
          dialogError(player, session, "setup-invalid", "dlg-invalid",
              ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
          openDialog(player);
          return;
        }
        if (!pin.equals(confirmOrNull)) {
          dialogError(player, session, "setup-mismatch", "dlg-mismatch", null);
          session.step1Pin("");
          session.mode(PinSession.Mode.SETUP_STEP1);
          openDialog(player);
          return;
        }
        persistAndUnlock(player, session, pin, cfg.msg("setup-success"), false);
        return;
      }
      if (!isFormatOk(pin)) {
        dialogError(player, session, "setup-invalid", "dlg-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength())));
        openDialog(player);
        return;
      }
      if (pin.equals(expected)) {
        persistAndUnlock(player, session, pin, cfg.msg("setup-success"), false);
      } else {
        session.clearBuffer();
        session.step1Pin("");
        session.mode(PinSession.Mode.SETUP_STEP1);
        dialogError(player, session, "setup-mismatch", "dlg-mismatch", null);
        openDialog(player);
      }
      return;
    }
  }

  // ---------- /pincreate command (explicit creation, same rules as setup) ----------

  public void createPinCommand(Player player, String pin, String confirm) {
    boolean has;
    try {
      has = storage.hasPin(player.getUniqueId());
    } catch (Exception ex) {
      has = false;
    }
    if (has) {
      send(player, cfg.msg("already-has-pin"));
      return;
    }
    if (!isFormatOk(pin)) {
      if (isForbidden(pin)) {
        send(player, cfg.msg("setup-forbidden"));
      } else {
        send(player, cfg.msg("setup-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength()))));
      }
      return;
    }
    if (!pin.equals(confirm)) {
      send(player, cfg.msg("setup-mismatch"));
      return;
    }
    PinSession session = sessions.get(player.getUniqueId());
    if (session != null && session.busy()) {
      return;
    }
    if (session != null) {
      session.busy(true);
    }
    SchedulerUtil.runAsync(plugin, () -> {
      setPin(player.getUniqueId(), player.getName(), pin);
      SchedulerUtil.runOnEntity(plugin, player, () -> {
        try {
          PinSession current = sessions.get(player.getUniqueId());
          if (current != null) {
            current.busy(false);
          }
          if (!player.isOnline()) {
            return;
          }
          playSound(player, "success", "block.note_block.pling", 0.8f, 1.4f);
          if (current != null) {
            unlock(player, cfg.msg("setup-success"));
          } else {
            send(player, cfg.msg("setup-success"));
          }
        } catch (Throwable t) {
          PinSession current = sessions.get(player.getUniqueId());
          if (current != null) {
            current.busy(false);
          }
          plugin.getLogger().warning("PinCreate failed for " + player.getName() + ": " + t.getMessage());
        }
      });
    });
  }

  // ---------- /repin ----------

  public void changePin(Player player, String oldPin, String newPin) {
    if (!isFormatOk(newPin)) {
      send(player, cfg.msg("setup-invalid",
          ConfigManager.ph("length", String.valueOf(cfg.pinLength()))));
      return;
    }
    if (oldPin.equals(newPin)) {
      send(player, cfg.msg("repin-same"));
      return;
    }
    SchedulerUtil.runAsync(plugin, () -> {
      PinRecord record;
      try {
        record = storage.get(player.getUniqueId());
      } catch (Exception ex) {
        record = null;
      }
      final PinRecord rec = record;
      SchedulerUtil.runOnEntity(plugin, player, () -> {
        if (!player.isOnline()) {
          return;
        }
        if (rec == null) {
          send(player, cfg.msg("no-pin"));
          return;
        }
        boolean ok = HashUtil.verify(cfg.hashAlgorithm(), rec.salt(), oldPin, rec.hash());
        if (!ok) {
          send(player, cfg.msg("repin-wrong-old"));
          return;
        }
        setPin(player.getUniqueId(), player.getName(), newPin);
        playSound(player, "success", "block.note_block.pling", 0.8f, 1.4f);
        PinSession session = sessions.get(player.getUniqueId());
        if (session != null) {
          unlock(player, cfg.msg("repin-success"));
        } else {
          send(player, cfg.msg("repin-success"));
        }
      });
    });
  }

  // ---------- admin ----------

  public void adminSetPin(CommandSender sender, String targetName, String newPin) {
    if (!isFormatOk(newPin)) {
      if (isForbidden(newPin)) {
        send(sender, cfg.msg("setup-forbidden"));
      } else {
        send(sender, cfg.msg("setup-invalid",
            ConfigManager.ph("length", String.valueOf(cfg.pinLength()))));
      }
      return;
    }
    Target target = resolveTarget(targetName);
    if (target == null) {
      send(sender, cfg.msg("admin-target-missing", ConfigManager.ph("player", targetName)));
      return;
    }
    // Storage write off the main thread (scales with big pins.yml).
    SchedulerUtil.runAsync(plugin, () -> {
      setPin(target.uuid(), target.name(), newPin);
      Player online = Bukkit.getPlayer(target.uuid());
      if (online != null && online.isOnline()) {
        SchedulerUtil.runOnEntity(plugin, online, () -> {
          send(sender, cfg.msg("admin-repin-success", ConfigManager.ph("player", target.name())));
          if (sessions.containsKey(target.uuid())) {
            PinSession session = sessions.get(target.uuid());
            session.mode(PinSession.Mode.LOGIN);
            session.attemptsLeft(cfg.maxAttempts());
            session.step1Pin("");
            session.clearBuffer();
            session.errorRaw("");
            openDialog(online);
          }
        });
      } else {
        SchedulerUtil.runOnEntity(plugin, sender instanceof Player ? (Player) sender : null, () -> {
          send(sender, cfg.msg("admin-repin-success", ConfigManager.ph("player", target.name())));
        });
      }
    });
  }

  public void adminReset(CommandSender sender, String targetName) {
    Target target = resolveTarget(targetName);
    if (target == null) {
      send(sender, cfg.msg("admin-target-missing", ConfigManager.ph("player", targetName)));
      return;
    }
    SchedulerUtil.runAsync(plugin, () -> {
      try {
        storage.delete(target.uuid());
      } catch (Exception ignored) {
        // non-fatal
      }
      Player online = Bukkit.getPlayer(target.uuid());
      if (online != null && online.isOnline()) {
        SchedulerUtil.runOnEntity(plugin, online, () -> {
          send(sender, cfg.msg("admin-reset-success", ConfigManager.ph("player", target.name())));
          if (sessions.containsKey(target.uuid())) {
            PinSession session = sessions.get(target.uuid());
            session.mode(PinSession.Mode.SETUP_STEP1);
            session.step1Pin("");
            session.clearBuffer();
            session.errorRaw("");
            openDialog(online);
          }
        });
      } else {
        SchedulerUtil.runOnEntity(plugin, sender instanceof Player ? (Player) sender : null, () -> {
          send(sender, cfg.msg("admin-reset-success", ConfigManager.ph("player", target.name())));
        });
      }
    });
  }

  public void adminStatus(CommandSender sender, String targetName) {
    Target target = resolveTarget(targetName);
    if (target == null) {
      send(sender, cfg.msg("admin-target-missing", ConfigManager.ph("player", targetName)));
      return;
    }
    Player onlineTarget = Bukkit.getPlayer(target.uuid());
    if (onlineTarget != null && isBedrockExempt(onlineTarget)) {
      send(sender, cfg.msg("admin-bedrock-exempt", ConfigManager.ph("player", target.name())));
      return;
    }
    boolean has;
    try {
      has = storage.hasPin(target.uuid());
    } catch (Exception ex) {
      has = false;
    }
    send(sender, cfg.msg(has ? "admin-has-pin" : "admin-no-pin",
        ConfigManager.ph("player", target.name())));
    send(sender, cfg.msg(isLocked(target.uuid()) ? "admin-locked" : "admin-unlocked",
        ConfigManager.ph("player", target.name())));
  }

  private Target resolveTarget(String name) {
    Player online = Bukkit.getPlayerExact(name);
    if (online != null) {
      return new Target(online.getUniqueId(), online.getName());
    }
    try {
      for (PinRecord record : storage.all()) {
        if (record.name() != null && record.name().equalsIgnoreCase(name)) {
          return new Target(UUID.fromString(record.uuid()), record.name());
        }
      }
    } catch (Exception ignored) {
      // fall through to offline lookup
    }
    try {
      OfflinePlayer offline = Bukkit.getOfflinePlayer(name);
      if (offline.hasPlayedBefore() || offline.isOnline()) {
        String realName = offline.getName() == null ? name : offline.getName();
        return new Target(offline.getUniqueId(), realName);
      }
    } catch (Exception ignored) {
      // unknown player
    }
    return null;
  }

  private record Target(UUID uuid, String name) {
  }

  // ---------- storage helpers ----------

  private void setPin(UUID uuid, String name, String pin) {
    long now = System.currentTimeMillis();
    PinRecord existing = null;
    try {
      existing = storage.get(uuid);
    } catch (Exception ignored) {
      // create new
    }
    long created = existing == null ? now : existing.createdAt();
    String salt = HashUtil.randomSalt(cfg.saltBytes());
    String hash = HashUtil.hash(cfg.hashAlgorithm(), salt, pin);
    try {
      storage.save(new PinRecord(uuid.toString(), name, hash, salt, created, now));
    } catch (Exception ex) {
      plugin.getLogger().warning("Failed to save PIN for " + name + ": " + ex.getMessage());
    }
  }

  public boolean isFormatOk(String pin) {
    if (pin == null || pin.length() != cfg.pinLength()) {
      return false;
    }
    if (cfg.numericOnly()) {
      for (int i = 0; i < pin.length(); i++) {
        char c = pin.charAt(i);
        if (c < '0' || c > '9') {
          return false;
        }
      }
    }
    if (cfg.forbidRepeatingDigit() && pin.length() > 1) {
      boolean same = true;
      for (int i = 1; i < pin.length(); i++) {
        if (pin.charAt(i) != pin.charAt(0)) {
          same = false;
          break;
        }
      }
      if (same) {
        return false;
      }
    }
    return !isForbidden(pin);
  }

  private boolean isForbidden(String pin) {
    for (String bad : cfg.forbiddenPins()) {
      if (pin.equals(bad)) {
        return true;
      }
    }
    return false;
  }

  // ---------- unlock / kick ----------

  /** Restores everyone still frozen (e.g. /reload wiped sessions). */
  public void shutdownRestore() {
    for (UUID id : sessions.keySet()) {
      try {
        Player player = Bukkit.getPlayer(id);
        if (player != null && player.isOnline()) {
          restoreMovement(player, sessions.get(id));
          try {
            player.closeDialog();
          } catch (Throwable ignored) {
            // best effort
          }
          try {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof com.uniqueteam.uniquepin.gui.PinInventoryHolder) {
              player.closeInventory();
            }
          } catch (Throwable ignored) {
          }
        }
      } catch (Throwable ignored) {
        // best effort
      }
    }
    sessions.clear();
    pendingFreeze.clear();
    moveBackup.clear();
    frozen.clear();
  }

  public void unlock(Player player, Component message) {
    UUID id = player.getUniqueId();
    lockouts.remove(id);
    PinSession session = sessions.remove(id);
    pendingFreeze.remove(id);
    // Movement is restored FIRST so it can never stay frozen even if
    // dialog closing explodes on some fork (Error, not Exception).
    restoreMovement(player, session);
    try {
      player.closeDialog();
    } catch (Throwable ignored) {
      // older client, no dialog open, or fork without closeDialog
    }
    try {
      if (player.getOpenInventory().getTopInventory().getHolder() instanceof com.uniqueteam.uniquepin.gui.PinInventoryHolder) {
        player.closeInventory();
      }
    } catch (Throwable ignored) {
    }
    // Login bookkeeping off the main thread (full pins.yml rewrite on big servers).
    SchedulerUtil.runAsync(plugin, () -> {
      try {
        storage.touchLogin(id);
      } catch (Exception ignored) {
        // non-fatal
      }
    });
    if (message != null) {
      send(player, message);
    }
  }

  public void kick(Player player, Component reason) {
    try {
      player.kick(reason);
    } catch (Exception ignored) {
      // already gone
    }
  }

  // ---------- watchdog (timeout + dialog reopen) ----------

  public void tick() {
    long now = System.currentTimeMillis();
    long timeout = cfg.timeoutMillis();
    long reopenAfter = cfg.reopenIntervalSeconds() * 1000L;
    for (Map.Entry<UUID, PinSession> entry : sessions.entrySet()) {
      UUID id = entry.getKey();
      PinSession session = entry.getValue();
      Player player = Bukkit.getPlayer(id);
      if (player == null || !player.isOnline()) {
        sessions.remove(id);
        continue;
      }
      if (session.isLockedOut()) {
        if (now >= session.lockoutUntil()) {
          lockouts.remove(id);
          session.lockoutUntil(0L);
          session.attemptsLeft(cfg.maxAttempts());
          session.clearBuffer();
          session.errorRaw("");
          send(player, cfg.msg("lockout-expired"));
          playSound(player, "success", "block.note_block.pling", 0.8f, 1.2f);
          openDialog(player);
        } else if (cfg.reopenEnabled() && now - session.lastDialogOpen() > reopenAfter) {
          long sec = session.remainingLockoutSeconds();
          session.errorRaw(cfg.rawMsg("dlg-locked-out", ConfigManager.ph("seconds", String.valueOf(sec))));
          openDialog(player);
        }
        continue;
      }
      if (now - session.joinTime() > timeout) {
        sessions.remove(id);
        kick(player, cfg.msg("timeout-kick",
            ConfigManager.ph("minutes", String.valueOf(cfg.timeoutMinutes()))));
        continue;
      }
      if (player.getOpenInventory().getTopInventory().getHolder() instanceof com.uniqueteam.uniquepin.gui.PinInventoryHolder) {
        continue;
      }
      if (cfg.reopenEnabled() && now - session.lastDialogOpen() > reopenAfter) {
        // Re-show even if a hack client closed the dialog: lock never depends on it.
        openDialog(player);
        sendChatPrompt(player);
      }
      // Unstick a confirm chain that never came back (scheduler hiccup).
      if (session.busy() && now - session.busySince() > 15000L) {
        session.busy(false);
        debug("unstuck busy " + player.getName());
        openDialog(player);
      }
    }
    // Heal anyone frozen without a session (can never stay movement-locked).
    for (UUID id : frozen) {
      if (sessions.containsKey(id) || pendingFreeze.contains(id)) {
        continue;
      }
      Player player = Bukkit.getPlayer(id);
      if (player == null || !player.isOnline()) {
        frozen.remove(id);
        moveBackup.remove(id);
        continue;
      }
      debug("heal frozen " + player.getName());
      restoreMovement(player, sessions.get(id));
    }
  }

  public int purgeInactive(long olderThanMillis) {
    if (!(storage instanceof YamlPinStorage)) {
      return -1;
    }
    int removed = 0;
    long now = System.currentTimeMillis();
    try {
      for (PinRecord record : storage.all()) {
        // Prefer real last-login; fall back to PIN update time.
        long seen = record.lastLogin() > 0 ? record.lastLogin() : record.updatedAt();
        if (seen > 0 && now - seen > olderThanMillis) {
          // Only purge when the record is genuinely old; never purge recent pins.
          try {
            storage.delete(UUID.fromString(record.uuid()));
            removed++;
          } catch (Exception ignored) {
            // continue with others
          }
        }
      }
    } catch (Exception ignored) {
      // purge is best-effort
    }
    return removed;
  }

  // ---------- freeze helpers ----------

  /** Previous movement state captured before freezing (restored on unlock). */
  private final Map<UUID, float[]> moveBackup = new ConcurrentHashMap<>();

  /**
   * Every UUID we ever froze. Watchdog heals anyone stuck here without a
   * session, so a frozen walk speed can never persist after unlock.
   */
  private final Set<UUID> frozen = ConcurrentHashMap.newKeySet();

  public void applyFreeze(Player player) {
    if (player == null || !player.isOnline()) {
      return;
    }
    if (isBedrockExempt(player)) {
      cleanupPlayer(player);
      return;
    }
    frozen.add(player.getUniqueId());
    try {
      player.setCollidable(false);
      player.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
    } catch (Exception ignored) {
    }
    boolean keepFlight = false;
    try {
      org.bukkit.GameMode gm = player.getGameMode();
      // Spectator/creative fly: never take flight away or they fall
      // straight through the world while the PIN screen is open.
      keepFlight = (gm == org.bukkit.GameMode.SPECTATOR || gm == org.bukkit.GameMode.CREATIVE);
    } catch (Exception ignored) {
      // unknown gamemode: use the safe path below
    }
    if (keepFlight) {
      // Freeze in place by zeroing speeds, flight stays on.
      try {
        player.setFlySpeed(0.0f);
      } catch (Exception ignored) {
        // non-fatal
      }
      try {
        player.setWalkSpeed(0.0f);
      } catch (Exception ignored) {
        // non-fatal
      }
      try {
        if (player.getAllowFlight() && !player.isFlying()) {
          player.setFlying(true);
        }
      } catch (Exception ignored) {
        // non-fatal
      }
    } else {
      try {
        player.setFlying(false);
      } catch (Exception ignored) {
        // adventure mode edge cases
      }
      try {
        player.setAllowFlight(false);
      } catch (Exception ignored) {
        // non-fatal
      }
      try {
        player.setWalkSpeed(0.0f);
      } catch (Exception ignored) {
        // non-fatal
      }
    }
    if (cfg.lock("freeze-effects")) {
      try {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,
            Integer.MAX_VALUE, 10, false, false, false));
      } catch (Exception ignored) {
        // non-fatal
      }
    }
    // Darkness while the PIN screen is open; removed on unlock.
    if (cfg.lock("darkness-effect")) {
      try {
        player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS,
            Integer.MAX_VALUE, 0, false, false, false));
      } catch (Exception ignored) {
        // non-fatal
      }
    }
  }

  private void restoreMovement(Player player, PinSession session) {
    if (player == null) {
      return;
    }
    frozen.remove(player.getUniqueId());
    float[] backup = moveBackup.remove(player.getUniqueId());
    float walk = 0.2f;
    float fly = 0.1f;
    boolean allowFlight = false;
    boolean flying = false;
    boolean collidable = true;
    if (session != null) {
      walk = session.prevWalkSpeed();
      fly = session.prevFlySpeed();
      allowFlight = session.prevAllowFlight();
      flying = session.prevFlying();
      collidable = session.prevCollidable();
    } else if (backup != null) {
      walk = backup[0];
      allowFlight = backup[1] > 0.5f;
      flying = backup[2] > 0.5f;
      fly = backup.length > 3 ? backup[3] : 0.1f;
      collidable = backup.length > 4 ? backup[4] > 0.5f : true;
    }
    if (walk < 0.19f || Float.isNaN(walk)) {
      walk = 0.2f;
    }
    if (fly < 0.05f || Float.isNaN(fly)) {
      fly = 0.1f;
    }
    final float finalWalk = walk;
    final float finalFly = fly;
    final boolean finalAllow = allowFlight;
    final boolean finalFlying = flying;
    final boolean finalCollidable = collidable;

    SchedulerUtil.runOnEntity(plugin, player, () -> {
      try {
        player.setCollidable(finalCollidable);
      } catch (Exception ignored) {
      }
      try {
        player.removePotionEffect(PotionEffectType.SLOWNESS);
      } catch (Exception ignored) {
      }
      try {
        player.removePotionEffect(PotionEffectType.DARKNESS);
      } catch (Exception ignored) {
      }
      try {
        player.setWalkSpeed(clampSpeed(finalWalk));
      } catch (Exception ignored) {
      }
      try {
        player.setFlySpeed(clampSpeed(finalFly));
      } catch (Exception ignored) {
      }
      try {
        player.setAllowFlight(finalAllow);
        if (finalFlying && finalAllow) {
          player.setFlying(true);
        }
      } catch (Exception ignored) {
      }
      try {
        player.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
        player.setFallDistance(0.0f);
      } catch (Exception ignored) {
      }
    });

    // 1-tick delayed assurance: completely prevents any lingering client attribute glitch
    SchedulerUtil.runOnEntityLater(plugin, player, 1L, () -> {
      if (player.isOnline()) {
        try {
          player.removePotionEffect(PotionEffectType.SLOWNESS);
          player.removePotionEffect(PotionEffectType.DARKNESS);
          if (player.getWalkSpeed() < 0.19f) {
            player.setWalkSpeed(finalWalk < 0.2f ? 0.2f : finalWalk);
          }
        } catch (Exception ignored) {
        }
      }
    });
  }

  private static float clampSpeed(float speed) {
    if (speed < -1.0f) {
      return -1.0f;
    }
    if (speed > 1.0f) {
      return 1.0f;
    }
    return speed;
  }

  private void send(Player player, Component message) {
    try {
      player.sendMessage(message);
    } catch (Exception ignored) {
      // non-fatal
    }
  }

  private void send(CommandSender sender, Component message) {
    try {
      sender.sendMessage(message);
    } catch (Exception ignored) {
      // non-fatal
    }
  }

  public boolean isBedrockExempt(Player player) {
    if (player == null || !cfg.bedrockExemptEnabled()) {
      return false;
    }
    // 1. Floodgate offline UUID check: Bedrock UUIDs from Floodgate always have mostSignificantBits == 0L
    // Instant, 0-cost, 100% reliable on join tick 0 even before Floodgate finishes player registration
    if (player.getUniqueId().getMostSignificantBits() == 0L) {
      return true;
    }
    // 2. Name prefix check (from config or common prefixes . and *)
    String name = player.getName();
    String prefix = cfg.bedrockPrefix();
    if (prefix != null && !prefix.isEmpty() && name.startsWith(prefix)) {
      return true;
    }
    if (name.startsWith(".") || name.startsWith("*")) {
      return true;
    }
    // 3. Floodgate API
    if (cfg.checkFloodgateApi()) {
      try {
        Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
        Object api = apiClass.getMethod("getInstance").invoke(null);
        if (api != null) {
          try {
            Object result = apiClass.getMethod("isFloodgateId", UUID.class).invoke(api, player.getUniqueId());
            if (Boolean.TRUE.equals(result)) {
              return true;
            }
          } catch (NoSuchMethodException ignored) {
          }
          try {
            Object result = apiClass.getMethod("isFloodgatePlayer", UUID.class).invoke(api, player.getUniqueId());
            if (Boolean.TRUE.equals(result)) {
              return true;
            }
          } catch (NoSuchMethodException ignored) {
          }
        }
      } catch (Throwable ignored) {
      }
    }
    // 4. Geyser API
    try {
      Class<?> geyserApiClass = Class.forName("org.geysermc.geyser.api.GeyserApi");
      Object geyserApi = geyserApiClass.getMethod("api").invoke(null);
      if (geyserApi != null) {
        Object result = geyserApiClass.getMethod("isBedrockPlayer", UUID.class).invoke(geyserApi, player.getUniqueId());
        if (Boolean.TRUE.equals(result)) {
          return true;
        }
      }
    } catch (Throwable ignored) {
    }
    return false;
  }

  public void sendChatPrompt(Player player) {
    if (player == null || !player.isOnline() || !cfg.openChatPrompt()) {
      return;
    }
    PinSession session = sessions.get(player.getUniqueId());
    boolean hasPin = false;
    if (session != null) {
      hasPin = (session.mode() == PinSession.Mode.LOGIN || session.mode() == PinSession.Mode.REPIN_OLD);
    } else {
      try {
        hasPin = storage.hasPin(player.getUniqueId());
      } catch (Exception ignored) {
      }
    }
    String key = hasPin ? "chat-prompt-login" : "chat-prompt-setup";
    Map<String, String> ph = ConfigManager.ph("length", String.valueOf(cfg.pinLength()));
    Component prompt = cfg.msg(key, ph)
        .clickEvent(net.kyori.adventure.text.event.ClickEvent.suggestCommand("/pin "));
    send(player, prompt);
  }

  private void debug(String message) {
    if (cfg.debug()) {
      plugin.getLogger().info("[debug] " + message);
    }
  }
}
