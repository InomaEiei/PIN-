package com.uniqueteam.uniquepin.pin;

import java.util.UUID;

/**
 * Runtime-only lock state. NEVER persisted: no session survives relog.
 */
public final class PinSession {

  public enum Mode {
    SETUP_STEP1,
    SETUP_CONFIRM,
    LOGIN,
    REPIN_OLD,
    REPIN_NEW
  }

  private final UUID uuid;
  private Mode mode;
  private final StringBuilder buffer = new StringBuilder();
  private String step1Pin = "";
  private String repinOld = "";
  private int attemptsLeft;
  private final long joinTime;
  private long lastDialogOpen;
  private volatile boolean busy;
  private volatile long busySince;

  // lockout timestamp (0 if not locked out)
  private volatile long lockoutUntil;

  // short error line embedded in the dialog (also mirrored to chat)
  private String errorRaw = "";

  // rate-limit window
  private long windowStart;
  private int windowClicks;

  // previous movement state (restored on unlock)
  private float prevWalkSpeed = 0.2f;
  private float prevFlySpeed = 0.1f;
  private boolean prevAllowFlight;
  private boolean prevFlying;
  private boolean prevCollidable = true;
  private boolean stateCaptured;
  private long lastReopenScheduled = 0L;

  public PinSession(UUID uuid, Mode mode, int attemptsLeft) {
    this.uuid = uuid;
    this.mode = mode;
    this.attemptsLeft = attemptsLeft;
    this.joinTime = System.currentTimeMillis();
    this.lastDialogOpen = 0L;
    this.windowStart = System.currentTimeMillis();
  }

  public UUID uuid() {
    return uuid;
  }

  public Mode mode() {
    return mode;
  }

  public void mode(Mode mode) {
    this.mode = mode;
  }

  public String buffer() {
    return buffer.toString();
  }

  public int bufferLength() {
    return buffer.length();
  }

  public boolean appendDigit(char digit, int maxLength) {
    if (buffer.length() >= maxLength) {
      return false;
    }
    buffer.append(digit);
    return true;
  }

  public boolean backspace() {
    if (buffer.length() == 0) {
      return false;
    }
    buffer.deleteCharAt(buffer.length() - 1);
    return true;
  }

  public void clearBuffer() {
    buffer.setLength(0);
  }

  public String step1Pin() {
    return step1Pin;
  }

  public void step1Pin(String step1Pin) {
    this.step1Pin = step1Pin == null ? "" : step1Pin;
  }

  public String repinOld() {
    return repinOld;
  }

  public void repinOld(String repinOld) {
    this.repinOld = repinOld == null ? "" : repinOld;
  }

  public int attemptsLeft() {
    return attemptsLeft;
  }

  public void attemptsLeft(int attemptsLeft) {
    this.attemptsLeft = attemptsLeft;
  }

  public long joinTime() {
    return joinTime;
  }

  public long lastDialogOpen() {
    return lastDialogOpen;
  }

  public void lastDialogOpen(long lastDialogOpen) {
    this.lastDialogOpen = lastDialogOpen;
  }

  public boolean busy() {
    return busy;
  }

  public void busy(boolean busy) {
    this.busy = busy;
    if (busy) {
      this.busySince = System.currentTimeMillis();
    }
  }

  public long busySince() {
    return busySince;
  }

  public String errorRaw() {
    return errorRaw;
  }

  public void errorRaw(String errorRaw) {
    this.errorRaw = errorRaw == null ? "" : errorRaw;
  }

  public boolean isLockedOut() {
    return lockoutUntil > 0L && System.currentTimeMillis() < lockoutUntil;
  }

  public long lockoutUntil() {
    return lockoutUntil;
  }

  public void lockoutUntil(long lockoutUntil) {
    this.lockoutUntil = lockoutUntil;
  }

  public long remainingLockoutSeconds() {
    if (!isLockedOut()) {
      return 0L;
    }
    return Math.max(1L, (lockoutUntil - System.currentTimeMillis() + 999L) / 1000L);
  }

  /** Sliding 1-second click rate limiter. */
  public synchronized boolean tryClick(int maxPerSecond) {
    long now = System.currentTimeMillis();
    if (now - windowStart >= 1000L) {
      windowStart = now;
      windowClicks = 0;
    }
    if (windowClicks >= maxPerSecond) {
      return false;
    }
    windowClicks++;
    return true;
  }

  public float prevWalkSpeed() {
    return prevWalkSpeed;
  }

  public float prevFlySpeed() {
    return prevFlySpeed;
  }

  public boolean prevAllowFlight() {
    return prevAllowFlight;
  }

  public boolean prevFlying() {
    return prevFlying;
  }

  public boolean prevCollidable() {
    return prevCollidable;
  }

  public void prevCollidable(boolean prevCollidable) {
    this.prevCollidable = prevCollidable;
  }

  public long lastReopenScheduled() {
    return lastReopenScheduled;
  }

  public void lastReopenScheduled(long lastReopenScheduled) {
    this.lastReopenScheduled = lastReopenScheduled;
  }

  public void captureState(float walkSpeed, boolean allowFlight, boolean flying) {
    captureState(walkSpeed, allowFlight, flying, 0.1f, true);
  }

  public void captureState(float walkSpeed, boolean allowFlight, boolean flying, float flySpeed) {
    captureState(walkSpeed, allowFlight, flying, flySpeed, true);
  }

  public void captureState(float walkSpeed, boolean allowFlight, boolean flying, float flySpeed, boolean collidable) {
    if (!stateCaptured) {
      this.prevWalkSpeed = walkSpeed;
      this.prevAllowFlight = allowFlight;
      this.prevFlying = flying;
      this.prevFlySpeed = flySpeed;
      this.prevCollidable = collidable;
      this.stateCaptured = true;
    }
  }
}
