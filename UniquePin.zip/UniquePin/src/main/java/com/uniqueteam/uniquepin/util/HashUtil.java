package com.uniqueteam.uniquepin.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

/**
 * SHA-256 + per-player random salt. The real PIN is never stored.
 */
public final class HashUtil {

  private static final SecureRandom RANDOM = new SecureRandom();
  private static final char[] HEX = "0123456789abcdef".toCharArray();

  private HashUtil() {
  }

  public static String randomSalt(int bytes) {
    byte[] buf = new byte[Math.max(8, bytes)];
    RANDOM.nextBytes(buf);
    return toHex(buf);
  }

  public static String hash(String algorithm, String salt, String pin) {
    try {
      MessageDigest md = MessageDigest.getInstance(algorithm);
      byte[] out = md.digest((salt + ":" + pin).getBytes(StandardCharsets.UTF_8));
      return toHex(out);
    } catch (Exception ex) {
      throw new IllegalStateException("Hash algorithm not available: " + algorithm, ex);
    }
  }

  public static boolean verify(String algorithm, String salt, String pin, String expectedHash) {
    if (salt == null || pin == null || expectedHash == null) {
      return false;
    }
    String actual = hash(algorithm, salt, pin);
    return constantTimeEquals(actual, expectedHash);
  }

  private static boolean constantTimeEquals(String a, String b) {
    if (a.length() != b.length()) {
      return false;
    }
    int diff = 0;
    for (int i = 0; i < a.length(); i++) {
      diff |= a.charAt(i) ^ b.charAt(i);
    }
    return diff == 0;
  }

  private static String toHex(byte[] bytes) {
    StringBuilder sb = new StringBuilder(bytes.length * 2);
    for (byte b : bytes) {
      sb.append(HEX[(b >> 4) & 0xF]);
      sb.append(HEX[b & 0xF]);
    }
    return sb.toString();
  }
}
