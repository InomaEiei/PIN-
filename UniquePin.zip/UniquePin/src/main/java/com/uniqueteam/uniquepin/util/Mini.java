package com.uniqueteam.uniquepin.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;

/**
 * MiniMessage helper with HEX support.
 * Applies non-italic by default so lore/dialog text never becomes italic by accident.
 */
public final class Mini {

  private static final MiniMessage MM = MiniMessage.miniMessage();

  private Mini() {
  }

  public static Component mm(String raw) {
    if (raw == null || raw.isEmpty()) {
      return Component.empty();
    }
    try {
      return MM.deserialize(raw).decoration(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    } catch (Exception ex) {
      return Component.text(raw).decoration(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }
  }

  public static String mask(int filled, int total) {
    StringBuilder sb = new StringBuilder();
    for (int i = 0; i < total; i++) {
      sb.append(i < filled ? "●" : "○");
    }
    return sb.toString();
  }
}
