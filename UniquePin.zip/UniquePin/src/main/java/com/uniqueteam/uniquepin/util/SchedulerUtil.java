package com.uniqueteam.uniquepin.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

/**
 * Folia & Paper safe scheduler.
 * Uses Folia / Paper schedulers (AsyncScheduler, GlobalRegionScheduler, EntityScheduler)
 * when available, otherwise falls back to standard BukkitScheduler.
 */
public final class SchedulerUtil {

  private static final boolean FOLIA;

  static {
    boolean folia = false;
    try {
      Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
      folia = true;
    } catch (Throwable t) {
      try {
        Bukkit.getServer().getClass().getMethod("getAsyncScheduler");
        folia = true;
      } catch (Throwable ignored) {
      }
    }
    FOLIA = folia;
  }

  private SchedulerUtil() {
  }

  public static boolean isFolia() {
    return FOLIA;
  }

  public static void runAsync(Plugin plugin, Runnable task) {
    if (FOLIA) {
      try {
        Bukkit.getAsyncScheduler().runNow(plugin, scheduledTask -> task.run());
        return;
      } catch (Throwable ignored) {
      }
    }
    try {
      Bukkit.getScheduler().runTaskAsynchronously(plugin, task);
    } catch (Throwable t) {
      new Thread(task, "UniquePin-AsyncThread").start();
    }
  }

  public static Object runLater(Plugin plugin, long delayTicks, Runnable task) {
    if (FOLIA) {
      try {
        return Bukkit.getGlobalRegionScheduler().runDelayed(plugin, scheduledTask -> task.run(), delayTicks);
      } catch (Throwable ignored) {
      }
    }
    return Bukkit.getScheduler().runTaskLater(plugin, task, delayTicks);
  }

  public static Object runTimer(Plugin plugin, long delayTicks, long periodTicks, Runnable task) {
    if (FOLIA) {
      try {
        return Bukkit.getGlobalRegionScheduler().runAtFixedRate(plugin, scheduledTask -> task.run(), delayTicks, periodTicks);
      } catch (Throwable ignored) {
      }
    }
    return Bukkit.getScheduler().runTaskTimer(plugin, task, delayTicks, periodTicks);
  }

  public static void runOnEntity(Plugin plugin, Entity entity, Runnable task) {
    if (entity == null) {
      return;
    }
    if (FOLIA) {
      try {
        entity.getScheduler().run(plugin, scheduledTask -> task.run(), null);
        return;
      } catch (Throwable ignored) {
      }
    }
    if (Bukkit.isPrimaryThread()) {
      task.run();
    } else {
      Bukkit.getScheduler().runTask(plugin, task);
    }
  }

  public static void runOnEntityLater(Plugin plugin, Entity entity, long delayTicks, Runnable task) {
    if (entity == null) {
      return;
    }
    if (FOLIA) {
      try {
        entity.getScheduler().runDelayed(plugin, scheduledTask -> task.run(), null, delayTicks);
        return;
      } catch (Throwable ignored) {
      }
    }
    Bukkit.getScheduler().runTaskLater(plugin, task, delayTicks);
  }

  public static void cancel(Object handle) {
    if (handle == null) {
      return;
    }
    if (handle instanceof io.papermc.paper.threadedregions.scheduler.ScheduledTask st) {
      try {
        st.cancel();
      } catch (Exception ignored) {
      }
      return;
    }
    if (handle instanceof org.bukkit.scheduler.BukkitTask bt) {
      try {
        bt.cancel();
      } catch (Exception ignored) {
      }
      return;
    }
    try {
      handle.getClass().getMethod("cancel").invoke(handle);
    } catch (Exception ignored) {
    }
  }
}
