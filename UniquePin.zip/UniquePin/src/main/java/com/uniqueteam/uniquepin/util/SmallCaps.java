package com.uniqueteam.uniquepin.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Converts normal A-Z letters to Unicode small caps.
 * Used for the biggest dialog title (UNIQUE PIN) and the hidden credit.
 */
public final class SmallCaps {

  private static final Map<Character, String> MAP = new HashMap<>();

  static {
    MAP.put('A', "ᴀ");
    MAP.put('B', "ʙ");
    MAP.put('C', "ᴄ");
    MAP.put('D', "ᴅ");
    MAP.put('E', "ᴇ");
    MAP.put('F', "ꜰ");
    MAP.put('G', "ɢ");
    MAP.put('H', "ʜ");
    MAP.put('I', "ɪ");
    MAP.put('J', "ᴊ");
    MAP.put('K', "ᴋ");
    MAP.put('L', "ʟ");
    MAP.put('M', "ᴍ");
    MAP.put('N', "ɴ");
    MAP.put('O', "ᴏ");
    MAP.put('P', "ᴘ");
    MAP.put('Q', "ǫ");
    MAP.put('R', "ʀ");
    MAP.put('S', "s");
    MAP.put('T', "ᴛ");
    MAP.put('U', "ᴜ");
    MAP.put('V', "ᴠ");
    MAP.put('W', "ᴡ");
    MAP.put('X', "x");
    MAP.put('Y', "ʏ");
    MAP.put('Z', "ᴢ");
  }

  private SmallCaps() {
  }

  public static String convert(String input) {
    if (input == null) {
      return "";
    }
    StringBuilder out = new StringBuilder(input.length());
    for (int i = 0; i < input.length(); i++) {
      char c = Character.toUpperCase(input.charAt(i));
      String mapped = MAP.get(c);
      out.append(mapped != null ? mapped : String.valueOf(input.charAt(i)));
    }
    return out.toString();
  }
}
