package com.uniqueteam.uniquepin.util;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.entity.Player;

/**
 * Vanilla noteblock sounds (sci-fi style). All sound keys are real vanilla
 * sound events; playback never throws into game threads.
 */
public final class SoundUtil {

  private SoundUtil() {
  }

  public static void play(Player player, String type, float volume, float pitch) {
    if (player == null || !player.isOnline()) {
      return;
    }
    if (type == null || type.isEmpty()) {
      return;
    }
    try {
      player.playSound(Sound.sound(Key.key("minecraft", type), Sound.Source.MASTER,
          clamp(volume, 0.0f, 1.0f), clamp(pitch, 0.5f, 2.0f)));
    } catch (Exception ignored) {
      // sound must never crash anything
    }
  }

  private static float clamp(float v, float min, float max) {
    return Math.max(min, Math.min(max, v));
  }
}
